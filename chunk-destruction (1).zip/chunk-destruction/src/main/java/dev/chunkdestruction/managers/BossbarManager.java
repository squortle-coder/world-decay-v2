package dev.chunkdestruction.managers;

import dev.chunkdestruction.ChunkDestructionPlugin;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.entity.Player;

public class BossbarManager {

    private final ChunkDestructionPlugin plugin;
    private BossBar bossBar;

    public BossbarManager(ChunkDestructionPlugin plugin) {
        this.plugin = plugin;
        createBossbar();
    }

    private void createBossbar() {
        bossBar = BossBar.bossBar(
            Component.text("Advancement Push: 0% — 0%").color(NamedTextColor.YELLOW),
            0f,
            BossBar.Color.YELLOW,
            BossBar.Overlay.NOTCHED_20
        );
    }

    public void update() {
        GameState gs = plugin.getGameState();
        if (!gs.isAdvancementPushEnabled()) {
            hideFromAll();
            return;
        }

        int min = gs.getAdvancementPushMin();
        int currentMax = gs.getAdvancementPushCurrentMax();
        float progress = Math.min(1f, currentMax / 100f);

        BossBar.Color color;
        if (currentMax <= 33) color = BossBar.Color.GREEN;
        else if (currentMax <= 66) color = BossBar.Color.YELLOW;
        else color = BossBar.Color.RED;

        Component title = Component.text("⚡ Decay Range: " + min + "% — " + currentMax + "%  ")
            .color(currentMax <= 33 ? NamedTextColor.GREEN : currentMax <= 66 ? NamedTextColor.YELLOW : NamedTextColor.RED)
            .decoration(TextDecoration.BOLD, true)
            .decoration(TextDecoration.ITALIC, false)
            .append(Component.text("(+" + gs.getAdvancementPushIncrement() + "% per advancement)")
                .color(NamedTextColor.GRAY)
                .decoration(TextDecoration.BOLD, false));

        bossBar.name(title);
        bossBar.progress(progress);
        bossBar.color(color);

        // Show to players who have it enabled
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            if (gs.isBossbarEnabled(p.getUniqueId())) {
                p.showBossBar(bossBar);
            } else {
                p.hideBossBar(bossBar);
            }
        }
    }

    public void showTo(Player player) {
        if (plugin.getGameState().isAdvancementPushEnabled() &&
            plugin.getGameState().isBossbarEnabled(player.getUniqueId())) {
            player.showBossBar(bossBar);
        }
    }

    public void hideFrom(Player player) {
        player.hideBossBar(bossBar);
    }

    public void hideFromAll() {
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            p.hideBossBar(bossBar);
        }
    }
}
