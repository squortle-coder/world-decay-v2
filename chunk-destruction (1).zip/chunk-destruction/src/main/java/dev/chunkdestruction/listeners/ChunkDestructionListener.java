package dev.chunkdestruction.listeners;

import dev.chunkdestruction.ChunkDestructionPlugin;
import dev.chunkdestruction.managers.GameState;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerAdvancementDoneEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.*;

public class ChunkDestructionListener implements Listener {

    private final ChunkDestructionPlugin plugin;
    private final Set<String> chunksInProgress = new HashSet<>();
    private final Set<Material> excluded = new HashSet<>();

    public ChunkDestructionListener(ChunkDestructionPlugin plugin) {
        this.plugin = plugin;
        loadExcluded();
    }

    public void reloadExcluded() { loadExcluded(); }

    private void loadExcluded() {
        excluded.clear();
        List<String> configList = plugin.getConfig().getStringList("excluded-blocks");
        for (String s : configList) {
            Material mat = Material.matchMaterial(s);
            if (mat != null) excluded.add(mat);
        }
    }

    // ─── Player-placed block tracking ───────────────────────────────────────

    @EventHandler(ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        Block b = event.getBlock();
        plugin.getGameState().markPlayerPlaced(b.getX(), b.getY(), b.getZ());
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Block b = event.getBlock();
        plugin.getGameState().unmarkPlayerPlaced(b.getX(), b.getY(), b.getZ());
    }

    // ─── Advancement Push ────────────────────────────────────────────────────

    @EventHandler
    public void onAdvancement(PlayerAdvancementDoneEvent event) {
        String key = event.getAdvancement().getKey().toString();
        if (key.contains("recipe/") || key.endsWith("/root")) return;

        GameState gs = plugin.getGameState();
        if (!gs.isAdvancementPushEnabled()) return;

        gs.incrementAdvancementPush();
        plugin.getBossbarManager().update();

        int newMax = gs.getAdvancementPushCurrentMax();
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.sendMessage(Component.text("⚡ Advancement earned! Decay range increased to " + gs.getAdvancementPushMin() + "—" + newMax + "%")
                .color(newMax <= 33 ? NamedTextColor.GREEN : newMax <= 66 ? NamedTextColor.YELLOW : NamedTextColor.RED)
                .decoration(TextDecoration.ITALIC, false));
        }
    }

    // ─── Player join ─────────────────────────────────────────────────────────

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            plugin.getBossbarManager().showTo(event.getPlayer());
        }, 40L);
    }

    // ─── Chunk entry ─────────────────────────────────────────────────────────

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerMove(PlayerMoveEvent event) {
        if (!plugin.getGameState().isEnabled()) return;
        if (event.getFrom().getChunk().equals(event.getTo().getChunk())) return;

        Player player = event.getPlayer();
        Chunk chunk = event.getTo().getChunk();
        String key = chunkKey(chunk);
        if (chunksInProgress.contains(key)) return;

        int percent = rollPercent();
        triggerDestruction(player, chunk, percent);
    }

    // ─── Rarity curve ────────────────────────────────────────────────────────

    private int rollPercent() {
        GameState gs = plugin.getGameState();

        // Advancement Push mode: flat distribution between min and currentMax
        if (gs.isAdvancementPushEnabled()) {
            int min = gs.getAdvancementPushMin();
            int max = gs.getAdvancementPushCurrentMax();
            if (min >= max) return min;
            return min + (int)(Math.random() * (max - min + 1));
        }

        // Normal mode: exponential curve biased toward low %
        int min = gs.getMinPercent();
        int max = gs.getMaxPercent();
        double lambda = 0.10;
        double u = Math.random();
        double raw = min + (-Math.log(1.0 - u) / lambda);
        return (int) Math.min(Math.max(Math.round(raw), min), max);
    }

    // ─── Destruction logic ───────────────────────────────────────────────────

    private void triggerDestruction(Player player, Chunk chunk, int percent) {
        String key = chunkKey(chunk);
        chunksInProgress.add(key);

        GameState gs = plugin.getGameState();
        World world = chunk.getWorld();
        int baseX = chunk.getX() * 16;
        int baseZ = chunk.getZ() * 16;
        int minY = world.getMinHeight();
        int maxY = world.getMaxHeight();

        // Collect candidates — sorted top to bottom (descending Y)
        List<Block> candidates = new ArrayList<>();
        for (int y = maxY - 1; y >= minY; y--) {
            for (int x = baseX; x < baseX + 16; x++) {
                for (int z = baseZ; z < baseZ + 16; z++) {
                    Block b = world.getBlockAt(x, y, z);
                    if (b.getType().isAir()) continue;
                    if (excluded.contains(b.getType())) continue;
                    if (gs.isProtectPlayerPlaced() && gs.isPlayerPlaced(x, y, z)) continue;
                    candidates.add(b);
                }
            }
        }

        if (candidates.isEmpty()) { chunksInProgress.remove(key); return; }

        // Pick blocks to destroy — keeping top-to-bottom order
        int count = Math.max(1, (int) Math.round(candidates.size() * (percent / 100.0)));

        // Reservoir sample to get <count> random blocks, then re-sort by Y descending
        List<Block> pool = new ArrayList<>(candidates);
        Collections.shuffle(pool);
        List<Block> toDestroy = new ArrayList<>(pool.subList(0, Math.min(count, pool.size())));
        toDestroy.sort((a, b) -> b.getY() - a.getY()); // top to bottom

        // Action bar
        if (gs.isActionbarEnabled(player.getUniqueId())) sendActionBar(player, percent);

        // Animate and break
        int durationTicks = gs.getDecayDurationTicks();
        runCrackThenBreak(player, toDestroy, key, durationTicks);
    }

    private void runCrackThenBreak(Player player, List<Block> blocks, String chunkKey, int durationTicks) {
        int fakeEntityId = -1000 - Math.abs(chunkKey.hashCode() % 10000);

        // Send crack stages 0-9 across durationTicks
        for (int stage = 0; stage <= 9; stage++) {
            final int s = stage;
            long delay = (long)(stage * ((double) durationTicks / 9.0));
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                for (Block block : blocks) {
                    block.getWorld().getNearbyPlayers(block.getLocation(), 64).forEach(p ->
                        p.sendBlockDamage(block.getLocation(), s / 9.0f, fakeEntityId));
                }
            }, delay);
        }

        // Break all blocks after animation — spread evenly across durationTicks
        int blocksPerTick = Math.max(1, (int) Math.ceil((double) blocks.size() / durationTicks));
        breakInBatches(blocks, 0, blocksPerTick, durationTicks, chunkKey, player);
    }

    private void breakInBatches(List<Block> blocks, int offset, int batchSize,
                                  int totalTicks, String chunkKey, Player player) {
        if (offset >= blocks.size()) { chunksInProgress.remove(chunkKey); return; }

        int end = Math.min(offset + batchSize, blocks.size());
        List<Block> batch = blocks.subList(offset, end);
        GameState gs = plugin.getGameState();

        for (Block block : batch) {
            if (block.getType().isAir()) continue;
            if (gs.isBreakSound() && gs.isSoundEnabled(player.getUniqueId())) {
                Sound sound = getBreakSound(block.getType());
                if (sound != null) block.getWorld().playSound(block.getLocation(), sound, 0.6f, 0.9f + (float)(Math.random() * 0.2f));
            }
            if (gs.isBlockDrops()) {
                block.breakNaturally();
            } else {
                block.setType(Material.AIR, false);
            }
        }

        // Schedule next batch — spread evenly across total duration
        long delayPerBatch = Math.max(1L, (long)(totalTicks / Math.ceil((double) blocks.size() / batchSize)));
        Bukkit.getScheduler().runTaskLater(plugin, () ->
            breakInBatches(blocks, end, batchSize, totalTicks, chunkKey, player), delayPerBatch);
    }

    // ─── Action bar ──────────────────────────────────────────────────────────

    private void sendActionBar(Player player, int percent) {
        TextColor colour;
        String icon;
        if (percent <= 20) { colour = NamedTextColor.GREEN; icon = "▼"; }
        else if (percent <= 35) { colour = NamedTextColor.YELLOW; icon = "▼▼"; }
        else { colour = TextColor.color(255, 60, 60); icon = "▼▼▼"; }

        Component bar = Component.text(icon + " " + percent + "% of chunk destroyed " + icon)
            .color(colour)
            .decoration(TextDecoration.BOLD, percent >= 35)
            .decoration(TextDecoration.ITALIC, false);

        player.sendActionBar(bar);
        for (int i = 1; i <= 3; i++) {
            final Component b = bar;
            Bukkit.getScheduler().runTaskLater(plugin, () -> player.sendActionBar(b), i * 20L);
        }
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    private String chunkKey(Chunk chunk) {
        return chunk.getWorld().getName() + ":" + chunk.getX() + ":" + chunk.getZ();
    }

    private Sound getBreakSound(Material mat) {
        String name = mat.name();
        if (name.contains("GLASS")) return Sound.BLOCK_GLASS_BREAK;
        if (name.contains("WOOD") || name.contains("LOG") || name.contains("PLANK") || name.contains("FENCE"))
            return Sound.BLOCK_WOOD_BREAK;
        if (name.contains("SAND") || name.contains("GRAVEL")) return Sound.BLOCK_SAND_BREAK;
        if (name.contains("GRASS") || name.contains("DIRT") || name.contains("MUD") || name.contains("MYCELIUM"))
            return Sound.BLOCK_GRASS_BREAK;
        if (name.contains("SNOW") || name.contains("ICE")) return Sound.BLOCK_SNOW_BREAK;
        if (name.contains("WOOL") || name.contains("CARPET")) return Sound.BLOCK_WOOL_BREAK;
        if (name.contains("DEEPSLATE")) return Sound.BLOCK_DEEPSLATE_BREAK;
        if (name.contains("LEAVES")) return Sound.BLOCK_GRASS_BREAK;
        if (name.contains("METAL") || name.contains("IRON") || name.contains("GOLD") || name.contains("COPPER"))
            return Sound.BLOCK_METAL_BREAK;
        return Sound.BLOCK_STONE_BREAK;
    }
}
