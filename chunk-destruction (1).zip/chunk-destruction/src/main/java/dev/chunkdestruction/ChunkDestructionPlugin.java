package dev.chunkdestruction;

import dev.chunkdestruction.gui.AdminSettingsGUI;
import dev.chunkdestruction.gui.PlayerSettingsGUI;
import dev.chunkdestruction.listeners.ChunkDestructionListener;
import dev.chunkdestruction.managers.BossbarManager;
import dev.chunkdestruction.managers.GameState;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class ChunkDestructionPlugin extends JavaPlugin {

    private static ChunkDestructionPlugin instance;
    private GameState gameState;
    private BossbarManager bossbarManager;
    private ChunkDestructionListener chunkListener;
    private PlayerSettingsGUI playerSettingsGUI;
    private AdminSettingsGUI adminSettingsGUI;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        gameState = new GameState(this);
        bossbarManager = new BossbarManager(this);
        chunkListener = new ChunkDestructionListener(this);
        playerSettingsGUI = new PlayerSettingsGUI(this);
        adminSettingsGUI = new AdminSettingsGUI(this);
        Bukkit.getPluginManager().registerEvents(chunkListener, this);
        Bukkit.getScheduler().runTaskTimer(this, () -> bossbarManager.update(), 40L, 40L);
        getLogger().info("ChunkDestruction enabled!");
    }

    @Override
    public void onDisable() {
        bossbarManager.hideFromAll();
        getLogger().info("ChunkDestruction disabled.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 1) { sender.sendMessage("§eUsage: /cd <on|off|reload|settings|admin>"); return true; }
        switch (args[0].toLowerCase()) {
            case "on", "off" -> {
                if (!sender.hasPermission("chunkdestruction.admin")) { sender.sendMessage("§cNo permission."); return true; }
                gameState.setEnabled(args[0].equalsIgnoreCase("on"));
                sender.sendMessage(gameState.isEnabled() ? "§aChunkDestruction enabled." : "§cChunkDestruction disabled.");
            }
            case "reload" -> {
                if (!sender.hasPermission("chunkdestruction.admin")) { sender.sendMessage("§cNo permission."); return true; }
                reloadConfig(); gameState.load(); chunkListener.reloadExcluded(); bossbarManager.update();
                sender.sendMessage("§aConfig reloaded.");
            }
            case "settings" -> {
                if (!(sender instanceof Player player)) { sender.sendMessage("Players only."); return true; }
                playerSettingsGUI.open(player);
            }
            case "admin" -> {
                if (!(sender instanceof Player player)) { sender.sendMessage("Players only."); return true; }
                if (!player.hasPermission("chunkdestruction.admin")) { player.sendMessage("§cNo permission."); return true; }
                adminSettingsGUI.open(player);
            }
            default -> sender.sendMessage("§eUsage: /cd <on|off|reload|settings|admin>");
        }
        return true;
    }

    public static ChunkDestructionPlugin getInstance() { return instance; }
    public GameState getGameState() { return gameState; }
    public BossbarManager getBossbarManager() { return bossbarManager; }
}
