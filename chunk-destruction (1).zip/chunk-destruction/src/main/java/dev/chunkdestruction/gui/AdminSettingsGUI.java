package dev.chunkdestruction.gui;

import dev.chunkdestruction.ChunkDestructionPlugin;
import dev.chunkdestruction.managers.GameState;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public class AdminSettingsGUI implements Listener {

    private final ChunkDestructionPlugin plugin;
    private static final Component TITLE = Component.text("⚙ Admin Settings")
        .color(TextColor.color(255, 150, 50))
        .decoration(TextDecoration.ITALIC, false);

    public AdminSettingsGUI(ChunkDestructionPlugin plugin) {
        this.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    public void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, TITLE);
        GameState gs = plugin.getGameState();

        // Fill with glass
        ItemStack glass = makeGlass();
        for (int i = 0; i < 54; i++) inv.setItem(i, glass);

        // Row 1: Core toggles
        inv.setItem(10, makeToggle(Material.LEVER, "Plugin Enabled",
            "Master toggle for chunk destruction", gs.isEnabled(), "enabled"));

        inv.setItem(12, makeToggle(Material.GRASS_BLOCK, "Block Drops",
            "Whether decayed blocks drop items", gs.isBlockDrops(), "drops"));

        inv.setItem(14, makeToggle(Material.BRICKS, "Protect Player Blocks",
            "Player-placed blocks won't decay", gs.isProtectPlayerPlaced(), "protect"));

        inv.setItem(16, makeToggle(Material.SKELETON_SKULL, "Hardcore Mode",
            "Players lose hearts on death", gs.isHardcore(), "hardcore"));

        // Row 2: Decay speed
        inv.setItem(19, makeInfo(Material.CLOCK,
            "Decay Speed: " + gs.getDecayDurationTicks() + " ticks",
            List.of("§7Time to break all blocks in a chunk",
                "§7(20 ticks = 1 second)",
                "§eLeft-click: §7-5 ticks  §eRight-click: §7+5 ticks",
                "§7Min: 5  Max: 200"), "speed"));

        // Row 2: Min/max percent
        inv.setItem(21, makeInfo(Material.LIME_DYE,
            "Min Decay %: " + gs.getMinPercent() + "%",
            List.of("§eLeft-click: §7-1%  §eRight-click: §7+1%"), "minpct"));

        inv.setItem(23, makeInfo(Material.RED_DYE,
            "Max Decay %: " + gs.getMaxPercent() + "%",
            List.of("§eLeft-click: §7-1%  §eRight-click: §7+1%"), "maxpct"));

        // Row 3: Advancement Push
        inv.setItem(28, makeToggle(Material.EXPERIENCE_BOTTLE, "Advancement Push",
            "Equal % range, grows with advancements", gs.isAdvancementPushEnabled(), "advpush"));

        inv.setItem(30, makeInfo(Material.ARROW,
            "AP Starting Max: " + gs.getAdvancementPushMax() + "%",
            List.of("§7Starting upper limit for Advancement Push",
                "§eLeft-click: §7-1%  §eRight-click: §7+1%"), "apmax"));

        inv.setItem(32, makeInfo(Material.EXPERIENCE_BOTTLE,
            "AP Increment: +" + gs.getAdvancementPushIncrement() + "%",
            List.of("§7% increase per advancement earned",
                "§eLeft-click: §7-1  §eRight-click: §7+1"), "apincrement"));

        inv.setItem(34, makeInfo(Material.RECOVERY_COMPASS,
            "AP Current Max: " + gs.getAdvancementPushCurrentMax() + "%",
            List.of("§7Current upper limit (resets on world reset)",
                "§eClick to reset to starting max"), "apreset"));

        // Row 4: Danger zone
        inv.setItem(46, makeItem(Material.TNT, "§c§lReset World",
            List.of("§7Teleports all players 1,000,000 blocks away",
                "§7and resets the world.",
                "§4§lThis cannot be undone!",
                "§eClick to confirm"), "resetworld"));

        player.openInventory(inv);
    }

    private ItemStack makeToggle(Material mat, String name, String desc, boolean enabled, String tag) {
        ItemStack item = new ItemStack(enabled ? mat : Material.BARRIER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name)
            .color(enabled ? NamedTextColor.GREEN : NamedTextColor.RED)
            .decoration(TextDecoration.ITALIC, false)
            .decoration(TextDecoration.BOLD, true));
        meta.lore(List.of(
            Component.text(desc).color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
            Component.empty(),
            Component.text(enabled ? "✔ Enabled — click to disable" : "✘ Disabled — click to enable")
                .color(enabled ? NamedTextColor.GREEN : NamedTextColor.RED)
                .decoration(TextDecoration.ITALIC, false)
        ));
        meta.getPersistentDataContainer().set(
            new org.bukkit.NamespacedKey(plugin, "cd_admin"),
            org.bukkit.persistence.PersistentDataType.STRING, tag);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack makeInfo(Material mat, String name, List<String> lore, String tag) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name).color(NamedTextColor.YELLOW)
            .decoration(TextDecoration.ITALIC, false).decoration(TextDecoration.BOLD, true));
        java.util.List<Component> loreComponents = new java.util.ArrayList<>();
        for (String s : lore) loreComponents.add(Component.text(s).decoration(TextDecoration.ITALIC, false));
        meta.lore(loreComponents);
        meta.getPersistentDataContainer().set(
            new org.bukkit.NamespacedKey(plugin, "cd_admin"),
            org.bukkit.persistence.PersistentDataType.STRING, tag);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack makeItem(Material mat, String name, List<String> lore, String tag) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name).decoration(TextDecoration.ITALIC, false));
        java.util.List<Component> loreComponents = new java.util.ArrayList<>();
        for (String s : lore) loreComponents.add(Component.text(s).decoration(TextDecoration.ITALIC, false));
        meta.lore(loreComponents);
        meta.getPersistentDataContainer().set(
            new org.bukkit.NamespacedKey(plugin, "cd_admin"),
            org.bukkit.persistence.PersistentDataType.STRING, tag);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack makeGlass() {
        ItemStack item = new ItemStack(Material.ORANGE_STAINED_GLASS_PANE);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(" ").decoration(TextDecoration.ITALIC, false));
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!event.getView().title().equals(TITLE)) return;
        event.setCancelled(true);
        if (!player.hasPermission("chunkdestruction.admin")) return;

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;

        String tag = clicked.getItemMeta().getPersistentDataContainer().get(
            new org.bukkit.NamespacedKey(plugin, "cd_admin"),
            org.bukkit.persistence.PersistentDataType.STRING);
        if (tag == null) return;

        boolean isRight = event.isRightClick();
        GameState gs = plugin.getGameState();

        switch (tag) {
            case "enabled" -> gs.setEnabled(!gs.isEnabled());
            case "drops" -> gs.setBlockDrops(!gs.isBlockDrops());
            case "protect" -> gs.setProtectPlayerPlaced(!gs.isProtectPlayerPlaced());
            case "hardcore" -> {
                gs.setHardcore(!gs.isHardcore());
                // Apply hardcore to all online players' worlds
                for (Player p : Bukkit.getOnlinePlayers()) {
                    p.getWorld().setHardcore(gs.isHardcore());
                }
            }
            case "speed" -> {
                int newSpeed = gs.getDecayDurationTicks() + (isRight ? 5 : -5);
                gs.setDecayDurationTicks(Math.max(5, Math.min(200, newSpeed)));
            }
            case "minpct" -> {
                int newMin = gs.getMinPercent() + (isRight ? 1 : -1);
                gs.setMinPercent(Math.max(1, Math.min(gs.getMaxPercent() - 1, newMin)));
            }
            case "maxpct" -> {
                int newMax = gs.getMaxPercent() + (isRight ? 1 : -1);
                gs.setMaxPercent(Math.max(gs.getMinPercent() + 1, Math.min(100, newMax)));
            }
            case "advpush" -> {
                gs.setAdvancementPushEnabled(!gs.isAdvancementPushEnabled());
                plugin.getBossbarManager().update();
            }
            case "apmax" -> {
                int newMax = gs.getAdvancementPushMax() + (isRight ? 1 : -1);
                gs.setAdvancementPushMax(Math.max(0, Math.min(100, newMax)));
            }
            case "apincrement" -> {
                int newInc = gs.getAdvancementPushIncrement() + (isRight ? 1 : -1);
                gs.setAdvancementPushIncrement(Math.max(1, newInc));
            }
            case "apreset" -> {
                gs.resetAdvancementPush();
                plugin.getBossbarManager().update();
                player.sendMessage(Component.text("§aAdvancement Push reset to starting max."));
            }
            case "resetworld" -> {
                player.sendMessage(Component.text("§c§lResetting world — teleporting all players..."));
                for (Player p : Bukkit.getOnlinePlayers()) {
                    p.teleport(new org.bukkit.Location(p.getWorld(), 1000000, 64, 1000000));
                    p.sendMessage(Component.text("§cThe world has been reset. You've been moved to safety."));
                }
                // Reset advancement push if enabled
                if (gs.isAdvancementPushEnabled()) {
                    gs.resetAdvancementPush();
                    plugin.getBossbarManager().update();
                }
            }
        }
        open(player); // refresh
    }
}
