package dev.chunkdestruction.gui;

import dev.chunkdestruction.ChunkDestructionPlugin;
import dev.chunkdestruction.managers.GameState;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.UUID;

public class PlayerSettingsGUI implements Listener {

    private final ChunkDestructionPlugin plugin;
    private static final Component TITLE = Component.text("⚙ Player Settings")
        .color(TextColor.color(100, 180, 255))
        .decoration(TextDecoration.ITALIC, false);

    public PlayerSettingsGUI(ChunkDestructionPlugin plugin) {
        this.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    public void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, TITLE);
        GameState gs = plugin.getGameState();
        UUID uuid = player.getUniqueId();

        // Fill with glass
        ItemStack glass = makeItem(Material.GRAY_STAINED_GLASS_PANE, " ", List.of());
        for (int i = 0; i < 27; i++) inv.setItem(i, glass);

        // Action bar toggle - slot 10
        boolean actionbar = gs.isActionbarEnabled(uuid);
        inv.setItem(10, makeToggle(Material.NAME_TAG, "Action Bar",
            "Shows chunk decay % above hotbar", actionbar, "actionbar"));

        // Sound toggle - slot 12
        boolean sound = gs.isSoundEnabled(uuid);
        inv.setItem(12, makeToggle(Material.NOTE_BLOCK, "Break Sounds",
            "Plays sound when blocks decay", sound, "sound"));

        // Bossbar toggle - slot 14 (only if advancement push is on)
        if (gs.isAdvancementPushEnabled()) {
            boolean bossbar = gs.isBossbarEnabled(uuid);
            inv.setItem(14, makeToggle(Material.DRAGON_HEAD, "Bossbar",
                "Shows Advancement Push progress bar", bossbar, "bossbar"));
        }

        player.openInventory(inv);
    }

    private ItemStack makeToggle(Material mat, String name, String desc, boolean enabled, String tag) {
        ItemStack item = new ItemStack(enabled ? mat : Material.BARRIER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name)
            .color(enabled ? NamedTextColor.GREEN : NamedTextColor.RED)
            .decoration(TextDecoration.ITALIC, false)
            .decoration(TextDecoration.BOLD, true));
        meta.lore(List.of(
            Component.text(desc).color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
            Component.empty(),
            Component.text(enabled ? "✔ Enabled — click to disable" : "✘ Disabled — click to enable")
                .color(enabled ? NamedTextColor.GREEN : NamedTextColor.RED)
                .decoration(TextDecoration.ITALIC, false)
        ));
        meta.getPersistentDataContainer().set(
            new org.bukkit.NamespacedKey(plugin, "cd_toggle"),
            org.bukkit.persistence.PersistentDataType.STRING, tag);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack makeItem(Material mat, String name, List<String> lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name).decoration(TextDecoration.ITALIC, false));
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!event.getView().title().equals(TITLE)) return;
        event.setCancelled(true);

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;

        String tag = clicked.getItemMeta().getPersistentDataContainer().get(
            new org.bukkit.NamespacedKey(plugin, "cd_toggle"),
            org.bukkit.persistence.PersistentDataType.STRING);
        if (tag == null) return;

        GameState gs = plugin.getGameState();
        UUID uuid = player.getUniqueId();

        switch (tag) {
            case "actionbar" -> {
                gs.toggleActionbar(uuid);
                player.sendMessage(Component.text("Action bar " + (gs.isActionbarEnabled(uuid) ? "§aenabled" : "§cdisabled") + "§r."));
            }
            case "sound" -> {
                gs.toggleSound(uuid);
                player.sendMessage(Component.text("Break sounds " + (gs.isSoundEnabled(uuid) ? "§aenabled" : "§cdisabled") + "§r."));
            }
            case "bossbar" -> {
                gs.toggleBossbar(uuid);
                if (gs.isBossbarEnabled(uuid)) plugin.getBossbarManager().showTo(player);
                else plugin.getBossbarManager().hideFrom(player);
                player.sendMessage(Component.text("Bossbar " + (gs.isBossbarEnabled(uuid) ? "§aenabled" : "§cdisabled") + "§r."));
            }
        }
        open(player); // refresh
    }
}
