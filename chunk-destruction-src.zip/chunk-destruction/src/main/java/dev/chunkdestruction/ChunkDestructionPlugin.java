package dev.chunkdestruction;

import dev.chunkdestruction.gui.AdminSettingsGUI;
import dev.chunkdestruction.gui.PlayerSettingsGUI;
import dev.chunkdestruction.listeners.ChunkDestructionListener;
import dev.chunkdestruction.managers.BossbarManager;
import dev.chunkdestruction.managers.GameState;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class ChunkDestructionPlugin extends JavaPlugin {

    private static ChunkDestructionPlugin instance;
    private GameState gameState;
    private BossbarManager bossbarManager;
    private ChunkDestructionListener chunkListener;
    private PlayerSettingsGUI playerSettingsGUI;
    private AdminSettingsGUI adminSettingsGUI;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        gameState        = new GameState(this);
        bossbarManager   = new BossbarManager(this);
        chunkListener    = new ChunkDestructionListener(this);
        playerSettingsGUI = new PlayerSettingsGUI(this);
        adminSettingsGUI  = new AdminSettingsGUI(this);

        Bukkit.getPluginManager().registerEvents(chunkListener, this);

        // Refresh bossbar every 2 seconds
        Bukkit.getScheduler().runTaskTimer(this, () -> bossbarManager.update(), 40L, 40L);

        getLogger().info("ChunkDestruction v" + getDescription().getVersion() + " enabled!");
    }

    @Override
    public void onDisable() {
        bossbarManager.hideFromAll();
        getLogger().info("ChunkDestruction disabled.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(Component.text("Usage: /cd <on|off|reload|settings|admin>")
                .color(NamedTextColor.YELLOW));
            return true;
        }

        switch (args[0].toLowerCase()) {

            case "on", "off" -> {
                if (!sender.hasPermission("chunkdestruction.admin")) {
                    sender.sendMessage(Component.text("You don't have permission.").color(NamedTextColor.RED));
                    return true;
                }
                boolean enable = args[0].equalsIgnoreCase("on");
                gameState.setEnabled(enable);
                sender.sendMessage(Component.text("ChunkDestruction " + (enable ? "enabled." : "disabled."))
                    .color(enable ? NamedTextColor.GREEN : NamedTextColor.RED));
            }

            case "reload" -> {
                if (!sender.hasPermission("chunkdestruction.admin")) {
                    sender.sendMessage(Component.text("You don't have permission.").color(NamedTextColor.RED));
                    return true;
                }
                reloadConfig();
                gameState.load();
                chunkListener.reloadExcluded();
                bossbarManager.update();
                sender.sendMessage(Component.text("Config reloaded.").color(NamedTextColor.GREEN));
            }

            case "settings" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("This command is for players only.");
                    return true;
                }
                playerSettingsGUI.open(player);
            }

            case "admin" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("This command is for players only.");
                    return true;
                }
                if (!player.hasPermission("chunkdestruction.admin")) {
                    player.sendMessage(Component.text("You don't have permission.").color(NamedTextColor.RED));
                    return true;
                }
                adminSettingsGUI.open(player);
            }

            default -> sender.sendMessage(Component.text("Usage: /cd <on|off|reload|settings|admin>")
                .color(NamedTextColor.YELLOW));
        }

        return true;
    }

    public static ChunkDestructionPlugin getInstance() { return instance; }
    public GameState getGameState()                    { return gameState; }
    public BossbarManager getBossbarManager()          { return bossbarManager; }
}
