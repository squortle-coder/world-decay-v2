package dev.chunkdestruction.managers;

import dev.chunkdestruction.ChunkDestructionPlugin;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class BossbarManager {

    private final ChunkDestructionPlugin plugin;
    private BossBar bossBar;

    public BossbarManager(ChunkDestructionPlugin plugin) {
        this.plugin = plugin;
        bossBar = buildBar();
    }

    private BossBar buildBar() {
        GameState gs = plugin.getGameState();
        int currentMax = gs.getAdvancementPushCurrentMax();
        int min = gs.getAdvancementPushMin();
        float progress = Math.min(1.0f, currentMax / 100.0f);

        BossBar.Color colour = currentMax <= 33 ? BossBar.Color.GREEN
                             : currentMax <= 66 ? BossBar.Color.YELLOW
                             : BossBar.Color.RED;

        Component title = Component.text("⚡ Advancement Push  ")
            .color(NamedTextColor.WHITE)
            .decoration(TextDecoration.ITALIC, false)
            .append(Component.text(min + "–" + currentMax + "%")
                .color(currentMax <= 33 ? NamedTextColor.GREEN
                     : currentMax <= 66 ? NamedTextColor.YELLOW
                     : NamedTextColor.RED)
                .decoration(TextDecoration.BOLD, true));

        return BossBar.bossBar(title, progress, colour, BossBar.Overlay.PROGRESS);
    }

    public void update() {
        GameState gs = plugin.getGameState();

        // Rebuild the bar with fresh values
        hideFromAll();
        bossBar = buildBar();

        if (!gs.isAdvancementPushEnabled() || !gs.isAdvancementPushBossbar()) return;

        for (Player p : Bukkit.getOnlinePlayers()) {
            if (gs.isBossbarEnabled(p.getUniqueId())) {
                p.showBossBar(bossBar);
            }
        }
    }

    public void showTo(Player player) {
        GameState gs = plugin.getGameState();
        if (gs.isAdvancementPushEnabled() && gs.isAdvancementPushBossbar()
                && gs.isBossbarEnabled(player.getUniqueId())) {
            player.showBossBar(bossBar);
        }
    }

    public void hideFrom(Player player) {
        player.hideBossBar(bossBar);
    }

    public void hideFromAll() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.hideBossBar(bossBar);
        }
    }
}
