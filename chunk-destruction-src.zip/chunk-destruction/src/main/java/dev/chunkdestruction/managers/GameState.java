package dev.chunkdestruction.managers;

import dev.chunkdestruction.ChunkDestructionPlugin;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class GameState {

    private final ChunkDestructionPlugin plugin;

    // Core
    private boolean enabled;
    private int minPercent;
    private int maxPercent;
    private int decayDurationTicks;
    private boolean blockDrops;
    private boolean protectPlayerPlaced;
    private boolean breakSound;
    private boolean hardcore;

    // Advancement Push
    private boolean advancementPushEnabled;
    private int advancementPushMin;
    private int advancementPushMax;
    private int advancementPushIncrement;
    private int advancementPushCurrentMax;
    private boolean advancementPushBossbar;

    // Per-player toggles (not persisted — reset on restart intentionally)
    private final Set<UUID> actionbarDisabled = new HashSet<>();
    private final Set<UUID> bossbarDisabled   = new HashSet<>();
    private final Set<UUID> soundDisabled      = new HashSet<>();

    // Player-placed block tracking (in-memory only)
    private final Set<Long> playerPlacedBlocks = new HashSet<>();

    public GameState(ChunkDestructionPlugin plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        FileConfiguration cfg = plugin.getConfig();
        enabled                  = cfg.getBoolean("enabled", true);
        minPercent               = cfg.getInt("min-percent", 2);
        maxPercent               = cfg.getInt("max-percent", 95);
        decayDurationTicks       = cfg.getInt("decay-duration-ticks", 40);
        blockDrops               = cfg.getBoolean("block-drops", false);
        protectPlayerPlaced      = cfg.getBoolean("protect-player-placed", false);
        breakSound               = cfg.getBoolean("break-sound", true);
        hardcore                 = cfg.getBoolean("hardcore", false);
        advancementPushEnabled   = cfg.getBoolean("advancement-push-enabled", false);
        advancementPushMin       = cfg.getInt("advancement-push-min", 0);
        advancementPushMax       = cfg.getInt("advancement-push-max", 10);
        advancementPushIncrement = cfg.getInt("advancement-push-increment", 1);
        advancementPushCurrentMax = cfg.getInt("advancement-push-current-max", advancementPushMax);
        advancementPushBossbar   = cfg.getBoolean("advancement-push-bossbar", true);
    }

    public void save() {
        FileConfiguration cfg = plugin.getConfig();
        cfg.set("enabled",                     enabled);
        cfg.set("min-percent",                 minPercent);
        cfg.set("max-percent",                 maxPercent);
        cfg.set("decay-duration-ticks",        decayDurationTicks);
        cfg.set("block-drops",                 blockDrops);
        cfg.set("protect-player-placed",       protectPlayerPlaced);
        cfg.set("break-sound",                 breakSound);
        cfg.set("hardcore",                    hardcore);
        cfg.set("advancement-push-enabled",    advancementPushEnabled);
        cfg.set("advancement-push-min",        advancementPushMin);
        cfg.set("advancement-push-max",        advancementPushMax);
        cfg.set("advancement-push-increment",  advancementPushIncrement);
        cfg.set("advancement-push-current-max", advancementPushCurrentMax);
        cfg.set("advancement-push-bossbar",    advancementPushBossbar);
        plugin.saveConfig();
    }

    // ── Block coordinate encoding ────────────────────────────────────────────
    public static long encodeBlock(int x, int y, int z) {
        return ((long)(x + 30000000) << 40) | ((long)(z + 30000000) << 16) | (y + 2048);
    }

    // ── Core getters/setters ─────────────────────────────────────────────────
    public boolean isEnabled()              { return enabled; }
    public void    setEnabled(boolean v)    { enabled = v; save(); }

    public int  getMinPercent()             { return minPercent; }
    public void setMinPercent(int v)        { minPercent = v; save(); }

    public int  getMaxPercent()             { return maxPercent; }
    public void setMaxPercent(int v)        { maxPercent = v; save(); }

    public int  getDecayDurationTicks()          { return decayDurationTicks; }
    public void setDecayDurationTicks(int v)     { decayDurationTicks = v; save(); }

    public boolean isBlockDrops()           { return blockDrops; }
    public void    setBlockDrops(boolean v) { blockDrops = v; save(); }

    public boolean isProtectPlayerPlaced()           { return protectPlayerPlaced; }
    public void    setProtectPlayerPlaced(boolean v) { protectPlayerPlaced = v; save(); }

    public boolean isBreakSound()           { return breakSound; }
    public void    setBreakSound(boolean v) { breakSound = v; save(); }

    public boolean isHardcore()             { return hardcore; }
    public void    setHardcore(boolean v)   { hardcore = v; save(); }

    // ── Advancement Push getters/setters ─────────────────────────────────────
    public boolean isAdvancementPushEnabled()            { return advancementPushEnabled; }
    public void    setAdvancementPushEnabled(boolean v)  { advancementPushEnabled = v; save(); }

    public int  getAdvancementPushMin()     { return advancementPushMin; }
    public void setAdvancementPushMin(int v){ advancementPushMin = v; save(); }

    public int  getAdvancementPushMax()     { return advancementPushMax; }
    public void setAdvancementPushMax(int v){ advancementPushMax = v; save(); }

    public int  getAdvancementPushIncrement()      { return advancementPushIncrement; }
    public void setAdvancementPushIncrement(int v) { advancementPushIncrement = v; save(); }

    public int  getAdvancementPushCurrentMax()     { return advancementPushCurrentMax; }
    public void setAdvancementPushCurrentMax(int v){ advancementPushCurrentMax = Math.min(v, 100); save(); }
    public void incrementAdvancementPush()         { advancementPushCurrentMax = Math.min(advancementPushCurrentMax + advancementPushIncrement, 100); save(); }
    public void resetAdvancementPush()             { advancementPushCurrentMax = advancementPushMax; save(); }

    public boolean isAdvancementPushBossbar()            { return advancementPushBossbar; }
    public void    setAdvancementPushBossbar(boolean v)  { advancementPushBossbar = v; save(); }

    // ── Per-player toggles ───────────────────────────────────────────────────
    public boolean isActionbarEnabled(UUID uuid) { return !actionbarDisabled.contains(uuid); }
    public void    toggleActionbar(UUID uuid) {
        if (!actionbarDisabled.remove(uuid)) actionbarDisabled.add(uuid);
    }

    public boolean isBossbarEnabled(UUID uuid) { return !bossbarDisabled.contains(uuid); }
    public void    toggleBossbar(UUID uuid) {
        if (!bossbarDisabled.remove(uuid)) bossbarDisabled.add(uuid);
    }

    public boolean isSoundEnabled(UUID uuid) { return !soundDisabled.contains(uuid); }
    public void    toggleSound(UUID uuid) {
        if (!soundDisabled.remove(uuid)) soundDisabled.add(uuid);
    }

    // ── Player-placed block tracking ─────────────────────────────────────────
    public void    markPlayerPlaced(int x, int y, int z)   { playerPlacedBlocks.add(encodeBlock(x, y, z)); }
    public void    unmarkPlayerPlaced(int x, int y, int z) { playerPlacedBlocks.remove(encodeBlock(x, y, z)); }
    public boolean isPlayerPlaced(int x, int y, int z)     { return playerPlacedBlocks.contains(encodeBlock(x, y, z)); }
}
