package dev.chunkdestruction.gui;

import dev.chunkdestruction.ChunkDestructionPlugin;
import dev.chunkdestruction.managers.GameState;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;
import java.util.UUID;

public class PlayerSettingsGUI implements Listener {

    private final ChunkDestructionPlugin plugin;
    private final NamespacedKey KEY;

    private static final Component TITLE = Component.text("⚙ Player Settings")
        .color(TextColor.color(100, 180, 255))
        .decoration(TextDecoration.ITALIC, false);

    public PlayerSettingsGUI(ChunkDestructionPlugin plugin) {
        this.plugin = plugin;
        this.KEY = new NamespacedKey(plugin, "cd_toggle");
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    public void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, TITLE);
        GameState gs = plugin.getGameState();
        UUID uuid = player.getUniqueId();

        // Fill background
        fillGlass(inv, 27, Material.GRAY_STAINED_GLASS_PANE);

        // Action bar toggle — slot 10
        inv.setItem(10, makeToggle(
            Material.NAME_TAG, "Action Bar",
            "Shows chunk decay % above your hotbar",
            gs.isActionbarEnabled(uuid), "actionbar"));

        // Sound toggle — slot 12
        inv.setItem(12, makeToggle(
            Material.NOTE_BLOCK, "Break Sounds",
            "Plays sound effects when blocks decay",
            gs.isSoundEnabled(uuid), "sound"));

        // Bossbar toggle — slot 14 (only when Advancement Push is active)
        if (gs.isAdvancementPushEnabled()) {
            inv.setItem(14, makeToggle(
                Material.DRAGON_HEAD, "Bossbar",
                "Shows the Advancement Push progress bar",
                gs.isBossbarEnabled(uuid), "bossbar"));
        }

        player.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!TITLE.equals(event.getView().title())) return;
        event.setCancelled(true);

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;

        String tag = clicked.getItemMeta().getPersistentDataContainer().get(KEY, PersistentDataType.STRING);
        if (tag == null) return;

        GameState gs = plugin.getGameState();
        UUID uuid = player.getUniqueId();

        switch (tag) {
            case "actionbar" -> {
                gs.toggleActionbar(uuid);
                player.sendMessage(Component.text("Action bar ")
                    .append(Component.text(gs.isActionbarEnabled(uuid) ? "enabled" : "disabled")
                        .color(gs.isActionbarEnabled(uuid) ? NamedTextColor.GREEN : NamedTextColor.RED))
                    .append(Component.text(".")));
            }
            case "sound" -> {
                gs.toggleSound(uuid);
                player.sendMessage(Component.text("Break sounds ")
                    .append(Component.text(gs.isSoundEnabled(uuid) ? "enabled" : "disabled")
                        .color(gs.isSoundEnabled(uuid) ? NamedTextColor.GREEN : NamedTextColor.RED))
                    .append(Component.text(".")));
            }
            case "bossbar" -> {
                gs.toggleBossbar(uuid);
                if (gs.isBossbarEnabled(uuid)) plugin.getBossbarManager().showTo(player);
                else plugin.getBossbarManager().hideFrom(player);
                player.sendMessage(Component.text("Bossbar ")
                    .append(Component.text(gs.isBossbarEnabled(uuid) ? "enabled" : "disabled")
                        .color(gs.isBossbarEnabled(uuid) ? NamedTextColor.GREEN : NamedTextColor.RED))
                    .append(Component.text(".")));
            }
        }

        open(player); // refresh
    }

    // ── Item builders ────────────────────────────────────────────────────────

    private ItemStack makeToggle(Material mat, String name, String desc, boolean enabled, String tag) {
        ItemStack item = new ItemStack(enabled ? mat : Material.BARRIER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name)
            .color(enabled ? NamedTextColor.GREEN : NamedTextColor.RED)
            .decoration(TextDecoration.ITALIC, false)
            .decoration(TextDecoration.BOLD, true));
        meta.lore(List.of(
            Component.text(desc).color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
            Component.empty(),
            Component.text(enabled ? "✔ Enabled — click to disable" : "✘ Disabled — click to enable")
                .color(enabled ? NamedTextColor.GREEN : NamedTextColor.RED)
                .decoration(TextDecoration.ITALIC, false)
        ));
        meta.getPersistentDataContainer().set(KEY, PersistentDataType.STRING, tag);
        item.setItemMeta(meta);
        return item;
    }

    private void fillGlass(Inventory inv, int size, Material mat) {
        ItemStack glass = new ItemStack(mat);
        ItemMeta meta = glass.getItemMeta();
        meta.displayName(Component.text(" ").decoration(TextDecoration.ITALIC, false));
        glass.setItemMeta(meta);
        for (int i = 0; i < size; i++) inv.setItem(i, glass);
    }
}
