package dev.chunkdestruction.gui;

import dev.chunkdestruction.ChunkDestructionPlugin;
import dev.chunkdestruction.managers.GameState;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class AdminSettingsGUI implements Listener {

    private final ChunkDestructionPlugin plugin;
    private final NamespacedKey KEY;

    private static final Component TITLE = Component.text("⚙ Admin Settings")
        .color(TextColor.color(255, 150, 50))
        .decoration(TextDecoration.ITALIC, false);

    public AdminSettingsGUI(ChunkDestructionPlugin plugin) {
        this.plugin = plugin;
        this.KEY = new NamespacedKey(plugin, "cd_admin");
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    public void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, TITLE);
        GameState gs = plugin.getGameState();

        fillGlass(inv, 54, Material.ORANGE_STAINED_GLASS_PANE);

        // ── Row 1: Core toggles (slots 10, 12, 14, 16) ──────────────────────
        inv.setItem(10, makeToggle(Material.LEVER, "Plugin Enabled",
            "Master on/off for chunk destruction",
            gs.isEnabled(), "enabled"));

        inv.setItem(12, makeToggle(Material.GRASS_BLOCK, "Block Drops",
            "Decayed blocks drop their items",
            gs.isBlockDrops(), "drops"));

        inv.setItem(14, makeToggle(Material.BRICKS, "Protect Player Blocks",
            "Player-placed blocks are immune to decay",
            gs.isProtectPlayerPlaced(), "protect"));

        inv.setItem(16, makeToggle(Material.SKELETON_SKULL, "Hardcore Mode",
            "World is set to hardcore difficulty",
            gs.isHardcore(), "hardcore"));

        // ── Row 2: Numeric settings (slots 19, 21, 23, 25) ──────────────────
        inv.setItem(19, makeAdjustable(Material.CLOCK,
            "Decay Speed: " + gs.getDecayDurationTicks() + " ticks",
            List.of(
                "§7Time to break all selected blocks",
                "§720 ticks = 1 second",
                "§eLeft-click §7−5 ticks  §eRight-click §7+5 ticks",
                "§7Range: 5–200 ticks"
            ), "speed"));

        inv.setItem(21, makeAdjustable(Material.LIME_DYE,
            "Min Decay: " + gs.getMinPercent() + "%",
            List.of(
                "§7Minimum % of chunk blocks that decay",
                "§eLeft-click §7−1%  §eRight-click §7+1%"
            ), "minpct"));

        inv.setItem(23, makeAdjustable(Material.RED_DYE,
            "Max Decay: " + gs.getMaxPercent() + "%",
            List.of(
                "§7Maximum % of chunk blocks that decay",
                "§eLeft-click §7−1%  §eRight-click §7+1%"
            ), "maxpct"));

        // ── Row 3: Advancement Push (slots 28, 30, 32, 34) ──────────────────
        inv.setItem(28, makeToggle(Material.EXPERIENCE_BOTTLE, "Advancement Push",
            "% range grows with each advancement earned",
            gs.isAdvancementPushEnabled(), "advpush"));

        inv.setItem(30, makeAdjustable(Material.ARROW,
            "AP Starting Max: " + gs.getAdvancementPushMax() + "%",
            List.of(
                "§7Upper limit when a new run begins",
                "§eLeft-click §7−1%  §eRight-click §7+1%"
            ), "apmax"));

        inv.setItem(32, makeAdjustable(Material.EXPERIENCE_BOTTLE,
            "AP Increment: +" + gs.getAdvancementPushIncrement() + "%",
            List.of(
                "§7% added to upper limit per advancement",
                "§eLeft-click §7−1  §eRight-click §7+1"
            ), "apincrement"));

        inv.setItem(34, makeAdjustable(Material.RECOVERY_COMPASS,
            "AP Current Max: " + gs.getAdvancementPushCurrentMax() + "%",
            List.of(
                "§7Live upper limit (grows during game)",
                "§eClick §7to reset back to starting max"
            ), "apreset"));

        // ── Row 4: Danger zone (slot 46) ─────────────────────────────────────
        inv.setItem(46, makeDanger(Material.TNT,
            "§c§lReset World",
            List.of(
                "§7Teleports all players 1,000,000 blocks away",
                "§7and resets Advancement Push progress.",
                "§4§lThis cannot be undone!",
                "§eClick to confirm"
            ), "resetworld"));

        player.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!TITLE.equals(event.getView().title())) return;
        event.setCancelled(true);
        if (!player.hasPermission("chunkdestruction.admin")) return;

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;

        String tag = clicked.getItemMeta().getPersistentDataContainer().get(KEY, PersistentDataType.STRING);
        if (tag == null) return;

        boolean right = event.isRightClick();
        GameState gs = plugin.getGameState();

        switch (tag) {
            case "enabled"  -> gs.setEnabled(!gs.isEnabled());
            case "drops"    -> gs.setBlockDrops(!gs.isBlockDrops());
            case "protect"  -> gs.setProtectPlayerPlaced(!gs.isProtectPlayerPlaced());
            case "hardcore" -> {
                gs.setHardcore(!gs.isHardcore());
                for (Player p : Bukkit.getOnlinePlayers()) {
                    p.getWorld().setHardcore(gs.isHardcore());
                }
            }
            case "speed" -> {
                int v = gs.getDecayDurationTicks() + (right ? 5 : -5);
                gs.setDecayDurationTicks(Math.max(5, Math.min(200, v)));
            }
            case "minpct" -> {
                int v = gs.getMinPercent() + (right ? 1 : -1);
                gs.setMinPercent(Math.max(1, Math.min(gs.getMaxPercent() - 1, v)));
            }
            case "maxpct" -> {
                int v = gs.getMaxPercent() + (right ? 1 : -1);
                gs.setMaxPercent(Math.max(gs.getMinPercent() + 1, Math.min(100, v)));
            }
            case "advpush" -> {
                gs.setAdvancementPushEnabled(!gs.isAdvancementPushEnabled());
                plugin.getBossbarManager().update();
            }
            case "apmax" -> {
                int v = gs.getAdvancementPushMax() + (right ? 1 : -1);
                gs.setAdvancementPushMax(Math.max(0, Math.min(100, v)));
            }
            case "apincrement" -> {
                int v = gs.getAdvancementPushIncrement() + (right ? 1 : -1);
                gs.setAdvancementPushIncrement(Math.max(1, v));
            }
            case "apreset" -> {
                gs.resetAdvancementPush();
                plugin.getBossbarManager().update();
                player.sendMessage(Component.text("Advancement Push reset to starting max.")
                    .color(NamedTextColor.GREEN));
            }
            case "resetworld" -> {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    p.teleport(new Location(p.getWorld(), 1_000_000, 64, 1_000_000));
                    p.sendMessage(Component.text("The world has been reset. You've been moved to safety.")
                        .color(NamedTextColor.RED));
                }
                if (gs.isAdvancementPushEnabled()) {
                    gs.resetAdvancementPush();
                    plugin.getBossbarManager().update();
                }
                player.sendMessage(Component.text("World reset complete.")
                    .color(NamedTextColor.GREEN));
            }
        }

        open(player); // refresh
    }

    // ── Item builders ────────────────────────────────────────────────────────

    private ItemStack makeToggle(Material mat, String name, String desc, boolean enabled, String tag) {
        ItemStack item = new ItemStack(enabled ? mat : Material.BARRIER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name)
            .color(enabled ? NamedTextColor.GREEN : NamedTextColor.RED)
            .decoration(TextDecoration.ITALIC, false)
            .decoration(TextDecoration.BOLD, true));
        meta.lore(List.of(
            Component.text(desc).color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
            Component.empty(),
            Component.text(enabled ? "✔ Enabled — click to disable" : "✘ Disabled — click to enable")
                .color(enabled ? NamedTextColor.GREEN : NamedTextColor.RED)
                .decoration(TextDecoration.ITALIC, false)
        ));
        meta.getPersistentDataContainer().set(KEY, PersistentDataType.STRING, tag);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack makeAdjustable(Material mat, String name, List<String> loreStrings, String tag) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name)
            .color(NamedTextColor.YELLOW)
            .decoration(TextDecoration.ITALIC, false)
            .decoration(TextDecoration.BOLD, true));
        List<Component> lore = new ArrayList<>();
        for (String s : loreStrings) lore.add(Component.text(s).decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(KEY, PersistentDataType.STRING, tag);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack makeDanger(Material mat, String name, List<String> loreStrings, String tag) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name).decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        for (String s : loreStrings) lore.add(Component.text(s).decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(KEY, PersistentDataType.STRING, tag);
        item.setItemMeta(meta);
        return item;
    }

    private void fillGlass(Inventory inv, int size, Material mat) {
        ItemStack glass = new ItemStack(mat);
        ItemMeta meta = glass.getItemMeta();
        meta.displayName(Component.text(" ").decoration(TextDecoration.ITALIC, false));
        glass.setItemMeta(meta);
        for (int i = 0; i < size; i++) inv.setItem(i, glass);
    }
}
