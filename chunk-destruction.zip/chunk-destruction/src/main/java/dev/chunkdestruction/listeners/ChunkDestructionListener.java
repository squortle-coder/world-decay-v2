package dev.chunkdestruction.listeners;

import dev.chunkdestruction.ChunkDestructionPlugin;
import dev.chunkdestruction.managers.GameState;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerAdvancementDoneEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.*;

public class ChunkDestructionListener implements Listener {

    private final ChunkDestructionPlugin plugin;
    private final Set<String> chunksInProgress = new HashSet<>();
    private final Set<Material> excluded = new HashSet<>();

    public ChunkDestructionListener(ChunkDestructionPlugin plugin) {
        this.plugin = plugin;
        loadExcluded();
    }

    public void reloadExcluded() { loadExcluded(); }

    private void loadExcluded() {
        excluded.clear();
        List<String> configList = plugin.getConfig().getStringList("excluded-blocks");
        for (String s : configList) {
            Material mat = Material.matchMaterial(s);
            if (mat != null) excluded.add(mat);
        }
    }

    // ─── Block place/break tracking ──────────────────────────────────────────

    @EventHandler(ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        Block b = event.getBlock();
        plugin.getGameState().markPlayerPlaced(b.getX(), b.getY(), b.getZ());
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Block b = event.getBlock();
        plugin.getGameState().unmarkPlayerPlaced(b.getX(), b.getY(), b.getZ());
    }

    // ─── Advancement Push ────────────────────────────────────────────────────

    @EventHandler
    public void onAdvancement(PlayerAdvancementDoneEvent event) {
        // Only trigger for advancements that actually show a chat announcement popup.
        // event.message() is non-null ONLY for those — it returns null for recipe unlocks,
        // root nodes, and silent advancements like individual item pickups.
        if (event.message() == null) return;

        GameState gs = plugin.getGameState();
        if (!gs.isAdvancementPushEnabled()) return;

        gs.incrementAdvancementPush();
        plugin.getBossbarManager().update();

        int newMax = gs.getAdvancementPushCurrentMax();
        int newMin = gs.getEffectiveMin();
        NamedTextColor col = newMax <= 33 ? NamedTextColor.GREEN : newMax <= 66 ? NamedTextColor.YELLOW : NamedTextColor.RED;
        String minStr = gs.isAdvancementPushMinGrows()
            ? newMin + "% — "
            : gs.getAdvancementPushStartMin() + "% — ";
        Bukkit.getOnlinePlayers().forEach(p -> p.sendMessage(
            Component.text("⚡ Advancement earned! Decay range: " + minStr + newMax + "%")
                .color(col).decoration(TextDecoration.ITALIC, false)));
    }

    // ─── Join ─────────────────────────────────────────────────────────────────

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Bukkit.getScheduler().runTaskLater(plugin, () -> plugin.getBossbarManager().showTo(event.getPlayer()), 40L);
    }

    // ─── Chunk entry ─────────────────────────────────────────────────────────

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerMove(PlayerMoveEvent event) {
        if (!plugin.getGameState().isEnabled()) return;
        if (event.getFrom().getChunk().equals(event.getTo().getChunk())) return;
        Player player = event.getPlayer();
        Chunk chunk = event.getTo().getChunk();
        String key = chunkKey(chunk);
        if (chunksInProgress.contains(key)) return;
        triggerDestruction(player, chunk, rollPercent());
    }

    // ─── Rarity curve ────────────────────────────────────────────────────────

    private int rollPercent() {
        GameState gs = plugin.getGameState();
        if (gs.isAdvancementPushEnabled()) {
            int min = gs.getEffectiveMin();
            int max = gs.getAdvancementPushCurrentMax();
            if (min >= max) return min;
            return min + (int)(Math.random() * (max - min + 1));
        }
        int min = gs.getMinPercent();
        int max = gs.getMaxPercent();
        double lambda = 0.10;
        double u = Math.random();
        double raw = min + (-Math.log(1.0 - u) / lambda);
        return (int) Math.min(Math.max(Math.round(raw), min), max);
    }

    // ─── Destruction ─────────────────────────────────────────────────────────

    private void triggerDestruction(Player player, Chunk chunk, int percent) {
        String key = chunkKey(chunk);
        chunksInProgress.add(key);
        GameState gs = plugin.getGameState();
        World world = chunk.getWorld();
        int baseX = chunk.getX() * 16;
        int baseZ = chunk.getZ() * 16;
        int minY = world.getMinHeight();
        int maxY = world.getMaxHeight();

        // Collect candidates top-to-bottom
        List<Block> candidates = new ArrayList<>();
        for (int y = maxY - 1; y >= minY; y--) {
            for (int x = baseX; x < baseX + 16; x++) {
                for (int z = baseZ; z < baseZ + 16; z++) {
                    Block b = world.getBlockAt(x, y, z);
                    if (b.getType().isAir()) continue;
                    if (excluded.contains(b.getType())) continue;
                    if (b.getType() == Material.BEDROCK && world.getEnvironment() == World.Environment.THE_END) continue;
                    if (gs.isProtectPlayerPlaced() && gs.isPlayerPlaced(x, y, z)) continue;
                    candidates.add(b);
                }
            }
        }

        if (candidates.isEmpty()) { chunksInProgress.remove(key); return; }

        // Pick random blocks to destroy, re-sort top-to-bottom
        int count = Math.max(1, (int) Math.round(candidates.size() * (percent / 100.0)));
        List<Block> pool = new ArrayList<>(candidates);
        Collections.shuffle(pool);
        List<Block> toDestroy = new ArrayList<>(pool.subList(0, Math.min(count, pool.size())));
        toDestroy.sort((a, b) -> b.getY() - a.getY());

        if (gs.isActionbarEnabled(player.getUniqueId())) sendActionBar(player, percent);

        int durationTicks = Math.max(1, gs.getDecayDurationTicks());
        runDecay(player, toDestroy, key, durationTicks);
    }

    /**
     * Decay in two phases:
     * 1. Crack animation: stages 0-9 spread across durationTicks
     * 2. Block breaking: ALL blocks broken spread evenly across durationTicks
     *
     * This fixes the "all break at once" bug — we calculate how many blocks
     * to break per tick based on total count and duration, ensuring smooth
     * spread across the full duration.
     */
    private void runDecay(Player player, List<Block> blocks, String chunkKey, int durationTicks) {
        int fakeId = -1000 - Math.abs(chunkKey.hashCode() % 10000);

        // Phase 1: crack animation across durationTicks
        for (int stage = 0; stage <= 9; stage++) {
            final int s = stage;
            // Space stages evenly, first at tick 0, last at tick durationTicks-1
            long delay = Math.round(stage * (durationTicks - 1.0) / 9.0);
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                for (Block block : blocks) {
                    block.getWorld().getNearbyPlayers(block.getLocation(), 64)
                        .forEach(p -> p.sendBlockDamage(block.getLocation(), s / 9.0f, fakeId));
                }
            }, delay);
        }

        // Phase 2: break blocks spread across durationTicks ticks
        // We schedule one batch per tick, sized so they spread evenly
        int total = blocks.size();
        int ticks = Math.max(1, durationTicks);

        for (int t = 0; t < ticks; t++) {
            // Calculate which slice of blocks to break this tick
            int startIdx = (int) Math.round((double) t / ticks * total);
            int endIdx   = (int) Math.round((double)(t + 1) / ticks * total);
            if (startIdx >= endIdx) continue;

            final List<Block> batch = new ArrayList<>(blocks.subList(startIdx, endIdx));
            final boolean isLastBatch = (t == ticks - 1);
            final String ck = chunkKey;

            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                GameState gs = plugin.getGameState();
                for (Block block : batch) {
                    if (block.getType().isAir()) continue;
                    if (gs.isBreakSound() && gs.isSoundEnabled(player.getUniqueId())) {
                        Sound snd = getBreakSound(block.getType());
                        if (snd != null) block.getWorld().playSound(block.getLocation(), snd,
                            0.6f, 0.9f + (float)(Math.random() * 0.2f));
                    }
                    if (gs.isBlockDrops()) block.breakNaturally();
                    else block.setType(Material.AIR, false);
                }
                if (isLastBatch) chunksInProgress.remove(ck);
            }, t); // tick t — one batch per tick, perfectly spread
        }
    }

    // ─── Action bar ──────────────────────────────────────────────────────────

    private void sendActionBar(Player player, int percent) {
        TextColor colour;
        String icon;
        if (percent <= 20)      { colour = NamedTextColor.GREEN;          icon = "▼"; }
        else if (percent <= 35) { colour = NamedTextColor.YELLOW;         icon = "▼▼"; }
        else                    { colour = TextColor.color(255, 60, 60);  icon = "▼▼▼"; }

        Component bar = Component.text(icon + " " + percent + "% of chunk destroyed " + icon)
            .color(colour)
            .decoration(TextDecoration.BOLD, percent >= 35)
            .decoration(TextDecoration.ITALIC, false);

        player.sendActionBar(bar);
        for (int i = 1; i <= 3; i++) {
            final Component b = bar;
            Bukkit.getScheduler().runTaskLater(plugin, () -> player.sendActionBar(b), i * 20L);
        }
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    private String chunkKey(Chunk chunk) {
        return chunk.getWorld().getName() + ":" + chunk.getX() + ":" + chunk.getZ();
    }

    private Sound getBreakSound(Material mat) {
        String n = mat.name();
        if (n.contains("GLASS"))  return Sound.BLOCK_GLASS_BREAK;
        if (n.contains("WOOD") || n.contains("LOG") || n.contains("PLANK") || n.contains("FENCE")) return Sound.BLOCK_WOOD_BREAK;
        if (n.contains("SAND") || n.contains("GRAVEL"))  return Sound.BLOCK_SAND_BREAK;
        if (n.contains("GRASS") || n.contains("DIRT") || n.contains("MUD")) return Sound.BLOCK_GRASS_BREAK;
        if (n.contains("SNOW") || n.contains("ICE"))     return Sound.BLOCK_SNOW_BREAK;
        if (n.contains("WOOL") || n.contains("CARPET"))  return Sound.BLOCK_WOOL_BREAK;
        if (n.contains("DEEPSLATE"))                     return Sound.BLOCK_DEEPSLATE_BREAK;
        if (n.contains("LEAVES"))                        return Sound.BLOCK_GRASS_BREAK;
        if (n.contains("IRON") || n.contains("GOLD") || n.contains("COPPER")) return Sound.BLOCK_METAL_BREAK;
        return Sound.BLOCK_STONE_BREAK;
    }
}
