package dev.chunkdestruction;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class ChunkDestructionPlugin extends JavaPlugin {

    private static ChunkDestructionPlugin instance;
    private ChunkDestructionListener listener;
    private boolean active;

    // Players who have turned their own actionbar off
    private final Set<UUID> actionbarDisabled = new HashSet<>();

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        active = getConfig().getBoolean("enabled", true);
        listener = new ChunkDestructionListener(this);
        Bukkit.getPluginManager().registerEvents(listener, this);
        getLogger().info("ChunkDestruction enabled. Active: " + active);
    }

    @Override
    public void onDisable() {
        getLogger().info("ChunkDestruction disabled.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 1) {
            sender.sendMessage("§eUsage: /cd <on|off|reload|actionbar>");
            return true;
        }

        switch (args[0].toLowerCase()) {

            // on/off — admin only
            case "on", "off" -> {
                if (!sender.hasPermission("chunkdestruction.admin")) {
                    sender.sendMessage("§cNo permission.");
                    return true;
                }
                active = args[0].equalsIgnoreCase("on");
                sender.sendMessage(active ? "§aChunkDestruction enabled." : "§cChunkDestruction disabled.");
            }

            // reload — admin only
            case "reload" -> {
                if (!sender.hasPermission("chunkdestruction.admin")) {
                    sender.sendMessage("§cNo permission.");
                    return true;
                }
                reloadConfig();
                listener.reloadExcluded();
                sender.sendMessage("§aConfig reloaded.");
            }

            // actionbar — any player, client-side toggle
            case "actionbar" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("Only players can toggle the actionbar.");
                    return true;
                }
                UUID uuid = player.getUniqueId();
                if (actionbarDisabled.contains(uuid)) {
                    actionbarDisabled.remove(uuid);
                    player.sendMessage("§aChunk destruction actionbar §lenabled§r§a.");
                } else {
                    actionbarDisabled.add(uuid);
                    player.sendMessage("§7Chunk destruction actionbar §ldisabled§r§7.");
                }
            }

            default -> sender.sendMessage("§eUsage: /cd <on|off|reload|actionbar>");
        }
        return true;
    }

    public boolean isActionbarEnabled(UUID uuid) {
        return !actionbarDisabled.contains(uuid);
    }

    public static ChunkDestructionPlugin getInstance() { return instance; }
    public boolean isActive() { return active; }
}
