package dev.chunkdestruction;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.*;

public class ChunkDestructionListener implements Listener {

    private final ChunkDestructionPlugin plugin;

    // Tracks which chunk coords are currently being animated, to avoid double-triggering
    private final Set<String> chunksInProgress = new HashSet<>();

    // Excluded block types loaded from config
    private final Set<Material> excluded = new HashSet<>();

    public ChunkDestructionListener(ChunkDestructionPlugin plugin) {
        this.plugin = plugin;
        loadExcluded();
    }

    public void reloadExcluded() { loadExcluded(); }

    private void loadExcluded() {
        excluded.clear();
        // Only config-defined blocks are excluded — nothing hardcoded
        List<String> configList = plugin.getConfig().getStringList("excluded-blocks");
        for (String s : configList) {
            Material mat = Material.matchMaterial(s);
            if (mat != null) excluded.add(mat);
        }
    }

    // ─── Chunk entry detection ───────────────────────────────────────────────

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerMove(PlayerMoveEvent event) {
        if (!plugin.isActive()) return;

        // Only care about chunk crossings
        if (event.getFrom().getChunk().equals(event.getTo().getChunk())) return;

        Player player = event.getPlayer();
        Chunk chunk = event.getTo().getChunk();
        String key = chunkKey(chunk);

        if (chunksInProgress.contains(key)) return;

        int percent = rollPercent();
        triggerDestruction(player, chunk, percent);
    }

    // ─── Rarity curve ────────────────────────────────────────────────────────

    /**
     * Exponential rarity curve biased heavily toward low percentages.
     * Uses inverse transform sampling on an exponential distribution.
     *
     * lambda = 0.10 with range 2-95 gives roughly:
     *   ~55% of rolls land between  2-15%
     *   ~28% between 15-35%
     *   ~12% between 35-60%
     *   ~4%  between 60-80%
     *   ~1%  between 80-95%   (95% is genuinely lottery-rare)
     *
     * The clamping at max means rolls that would exceed 95 just become 95,
     * making the exact maximum slightly more common than the curve alone
     * would suggest — but still extraordinarily rare.
     */
    private int rollPercent() {
        int min = plugin.getConfig().getInt("min-percent", 2);
        int max = plugin.getConfig().getInt("max-percent", 95);
        double lambda = 0.10;
        double u = Math.random();
        // Inverse CDF of exponential, shifted to start at min
        double raw = min + (-Math.log(1.0 - u) / lambda);
        return (int) Math.min(Math.max(Math.round(raw), min), max);
    }

    // ─── Destruction logic ───────────────────────────────────────────────────

    private void triggerDestruction(Player player, Chunk chunk, int percent) {
        String key = chunkKey(chunk);
        chunksInProgress.add(key);

        // Collect all non-air, non-excluded blocks in the chunk
        List<Block> candidates = new ArrayList<>();
        World world = chunk.getWorld();
        int baseX = chunk.getX() * 16;
        int baseZ = chunk.getZ() * 16;
        int minY = world.getMinHeight();
        int maxY = world.getMaxHeight();

        for (int x = baseX; x < baseX + 16; x++) {
            for (int z = baseZ; z < baseZ + 16; z++) {
                for (int y = minY; y < maxY; y++) {
                    Block b = world.getBlockAt(x, y, z);
                    if (b.getType().isAir()) continue;
                    if (excluded.contains(b.getType())) continue;
                    candidates.add(b);
                }
            }
        }

        if (candidates.isEmpty()) {
            chunksInProgress.remove(key);
            return;
        }

        // Shuffle and pick the percentage to destroy
        Collections.shuffle(candidates);
        int count = Math.max(1, (int) Math.round(candidates.size() * (percent / 100.0)));
        List<Block> toDestroy = candidates.subList(0, count);

        // Show action bar message (respects per-player toggle)
        if (plugin.isActionbarEnabled(player.getUniqueId())) sendActionBar(player, percent);

        // Run the crack animation then break
        runCrackAnimation(player, toDestroy, key);
    }

    /**
     * Sends crack stage packets (0-9) over crack-duration-ticks,
     * then breaks all blocks with sound but no drops.
     */
    private void runCrackAnimation(Player player, List<Block> blocks, String chunkKey) {
        int crackTicks = plugin.getConfig().getInt("crack-duration-ticks", 10);
        int blocksPerTick = plugin.getConfig().getInt("blocks-per-tick", 20);

        // We'll cycle through crack stages 0-9 evenly over crackTicks
        // Using entity ID -1000 as a fake entity ID for the crack packet (won't conflict with real entities)
        int fakeEntityId = -1000 - Math.abs(chunkKey.hashCode() % 10000);

        // Send crack stages spread across the animation duration
        for (int stage = 0; stage <= 9; stage++) {
            final int s = stage;
            long delay = (long) (stage * ((double) crackTicks / 9.0));
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                for (Block block : blocks) {
                    // Send block damage packet to all nearby players
                    block.getWorld().getNearbyPlayers(block.getLocation(), 64).forEach(p ->
                        p.sendBlockDamage(block.getLocation(), s / 9.0f, fakeEntityId)
                    );
                }
            }, delay);
        }

        // After animation completes, break the blocks in batches
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            breakBlocksInBatches(blocks, blocksPerTick, chunkKey);
        }, crackTicks + 1L);
    }

    /**
     * Breaks blocks in batches across ticks to avoid server lag spikes.
     * Plays the break sound but drops nothing.
     */
    private void breakBlocksInBatches(List<Block> blocks, int batchSize, String chunkKey) {
        if (blocks.isEmpty()) {
            chunksInProgress.remove(chunkKey);
            return;
        }

        int end = Math.min(batchSize, blocks.size());
        List<Block> batch = new ArrayList<>(blocks.subList(0, end));
        List<Block> remaining = new ArrayList<>(blocks.subList(end, blocks.size()));

        for (Block block : batch) {
            if (block.getType().isAir()) continue;

            // Play the block's break sound (no crack noise — just the final break)
            Sound sound = getBreakSound(block.getType());
            if (sound != null) {
                block.getWorld().playSound(block.getLocation(), sound, 0.8f, 0.9f + (float)(Math.random() * 0.2f));
            }

            // Break without drops, without exp, without block physics for speed
            block.setType(Material.AIR, false);
        }

        if (!remaining.isEmpty()) {
            Bukkit.getScheduler().runTaskLater(plugin, () ->
                breakBlocksInBatches(remaining, batchSize, chunkKey), 1L);
        } else {
            chunksInProgress.remove(chunkKey);
        }
    }

    // ─── Action bar ──────────────────────────────────────────────────────────

    private void sendActionBar(Player player, int percent) {
        TextColor colour;
        String icon;
        if (percent <= 20) {
            colour = NamedTextColor.GREEN;
            icon = "▼";
        } else if (percent <= 35) {
            colour = NamedTextColor.YELLOW;
            icon = "▼▼";
        } else {
            colour = TextColor.color(255, 60, 60); // bright red
            icon = "▼▼▼";
        }

        Component bar = Component.text(icon + " " + percent + "% of chunk destroyed " + icon)
            .color(colour)
            .decoration(TextDecoration.BOLD, percent >= 35)
            .decoration(TextDecoration.ITALIC, false);

        player.sendActionBar(bar);

        // Keep it visible for 4 seconds (action bar fades after ~3s, so refresh it)
        for (int i = 1; i <= 3; i++) {
            final Component b = bar;
            Bukkit.getScheduler().runTaskLater(plugin, () -> player.sendActionBar(b), i * 20L);
        }
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    private String chunkKey(Chunk chunk) {
        return chunk.getWorld().getName() + ":" + chunk.getX() + ":" + chunk.getZ();
    }

    /**
     * Returns an appropriate break sound for a material.
     * Falls back to STONE if the material doesn't have a nice match.
     */
    private Sound getBreakSound(Material mat) {
        String name = mat.name();
        if (name.contains("GLASS")) return Sound.BLOCK_GLASS_BREAK;
        if (name.contains("WOOD") || name.contains("LOG") || name.contains("PLANK")
                || name.contains("FENCE") || name.contains("DOOR") && !name.contains("IRON"))
            return Sound.BLOCK_WOOD_BREAK;
        if (name.contains("SAND") || name.contains("GRAVEL"))
            return Sound.BLOCK_SAND_BREAK;
        if (name.contains("GRASS") || name.contains("DIRT") || name.contains("MUD")
                || name.contains("MYCELIUM") || name.contains("PATH"))
            return Sound.BLOCK_GRASS_BREAK;
        if (name.contains("SNOW") || name.contains("ICE"))
            return Sound.BLOCK_SNOW_BREAK;
        if (name.contains("WOOL") || name.contains("CARPET"))
            return Sound.BLOCK_WOOL_BREAK;
        if (name.contains("SHROOMLIGHT") || name.contains("WART")
                || name.contains("FUNGUS") || name.contains("ROOTS"))
            return Sound.BLOCK_NETHER_WART_BREAK;
        if (name.contains("DEEPSLATE"))
            return Sound.BLOCK_DEEPSLATE_BREAK;
        if (name.contains("STONE") || name.contains("ORE") || name.contains("COBBLE")
                || name.contains("BRICK") || name.contains("BASALT") || name.contains("ANDESITE")
                || name.contains("GRANITE") || name.contains("DIORITE") || name.contains("OBSIDIAN")
                || name.contains("NETHERRACK") || name.contains("BLACKSTONE"))
            return Sound.BLOCK_STONE_BREAK;
        if (name.contains("LEAVES"))
            return Sound.BLOCK_GRASS_BREAK;
        if (name.contains("METAL") || name.contains("IRON") || name.contains("GOLD")
                || name.contains("COPPER") || name.contains("CHAIN"))
            return Sound.BLOCK_METAL_BREAK;
        return Sound.BLOCK_STONE_BREAK; // sensible fallback
    }
}
