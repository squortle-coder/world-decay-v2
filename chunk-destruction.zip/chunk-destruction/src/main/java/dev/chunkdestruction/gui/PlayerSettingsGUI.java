package dev.chunkdestruction.gui;

import dev.chunkdestruction.ChunkDestructionPlugin;
import dev.chunkdestruction.managers.GameState;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;
import java.util.UUID;

public class PlayerSettingsGUI implements Listener {

    private final ChunkDestructionPlugin plugin;
    private static final Component TITLE = Component.text("⚙ Player Settings")
        .color(TextColor.color(100, 180, 255)).decoration(TextDecoration.ITALIC, false);

    public PlayerSettingsGUI(ChunkDestructionPlugin plugin) {
        this.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    public void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, TITLE);
        GameState gs = plugin.getGameState();
        UUID uuid = player.getUniqueId();

        // Fill border
        ItemStack glass = border();
        for (int i = 0; i < 27; i++) inv.setItem(i, glass);

        inv.setItem(10, makeToggle(Material.NAME_TAG, "Action Bar",
            "Shows chunk decay % above your hotbar", gs.isActionbarEnabled(uuid), "actionbar"));

        inv.setItem(13, makeToggle(Material.NOTE_BLOCK, "Break Sounds",
            "Plays sound when blocks decay", gs.isSoundEnabled(uuid), "sound"));

        if (gs.isAdvancementPushEnabled()) {
            inv.setItem(16, makeToggle(Material.DRAGON_HEAD, "Advancement Bossbar",
                "Shows Advancement Push progress bar", gs.isBossbarEnabled(uuid), "bossbar"));
        }

        player.openInventory(inv);
    }

    private ItemStack makeToggle(Material mat, String name, String desc, boolean enabled, String tag) {
        ItemStack item = new ItemStack(enabled ? mat : Material.BARRIER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name)
            .color(enabled ? NamedTextColor.GREEN : NamedTextColor.RED)
            .decoration(TextDecoration.ITALIC, false).decoration(TextDecoration.BOLD, true));
        meta.lore(List.of(
            Component.text(desc).color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
            Component.empty(),
            Component.text(enabled ? "✔ Enabled  —  click to disable" : "✘ Disabled  —  click to enable")
                .color(enabled ? NamedTextColor.GREEN : NamedTextColor.RED).decoration(TextDecoration.ITALIC, false)
        ));
        meta.getPersistentDataContainer().set(new NamespacedKey(plugin, "cd_toggle"), PersistentDataType.STRING, tag);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack border() {
        ItemStack item = new ItemStack(Material.BLUE_STAINED_GLASS_PANE);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(" ").decoration(TextDecoration.ITALIC, false));
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!event.getView().title().equals(TITLE)) return;
        event.setCancelled(true);

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;
        String tag = clicked.getItemMeta().getPersistentDataContainer()
            .get(new NamespacedKey(plugin, "cd_toggle"), PersistentDataType.STRING);
        if (tag == null) return;

        GameState gs = plugin.getGameState();
        UUID uuid = player.getUniqueId();
        switch (tag) {
            case "actionbar" -> gs.toggleActionbar(uuid);
            case "sound" -> gs.toggleSound(uuid);
            case "bossbar" -> {
                gs.toggleBossbar(uuid);
                if (gs.isBossbarEnabled(uuid)) plugin.getBossbarManager().showTo(player);
                else plugin.getBossbarManager().hideFrom(player);
            }
        }
        open(player);
    }
}
