package dev.chunkdestruction.gui;

import dev.chunkdestruction.ChunkDestructionPlugin;
import dev.chunkdestruction.managers.GameState;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class AdminSettingsGUI implements Listener {

    private final ChunkDestructionPlugin plugin;
    private final Random random = new Random();

    private static final Component TITLE = Component.text("⚙ Admin Settings")
        .color(TextColor.color(255, 150, 50)).decoration(TextDecoration.ITALIC, false);

    // Layout — 6 rows (54 slots)
    // Row 0 (0-8):   Header / labels
    // Row 1 (9-17):  GROUP 1 — Core toggles
    // Row 2 (18-26): GROUP 2 — Decay tuning
    // Row 3 (27-35): GROUP 3 — Advancement Push
    // Row 4 (36-44): GROUP 4 — Advancement Push numbers
    // Row 5 (45-53): Danger zone

    public AdminSettingsGUI(ChunkDestructionPlugin plugin) {
        this.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    public void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, TITLE);
        GameState gs = plugin.getGameState();

        // Fill all with dark border
        for (int i = 0; i < 54; i++) inv.setItem(i, border(Material.GRAY_STAINED_GLASS_PANE));

        // ── Section headers (coloured glass labels) ──────────────────────────
        fillRow(inv, 0, border(Material.ORANGE_STAINED_GLASS_PANE));
        inv.setItem(4, sectionHeader("⚙ Admin Settings — ChunkDestruction v2.1.0"));

        // Separator rows between groups
        fillRow(inv, 2, border(Material.ORANGE_STAINED_GLASS_PANE));
        fillRow(inv, 4, border(Material.ORANGE_STAINED_GLASS_PANE));

        // ── GROUP 1: Core (row 1) ─────────────────────────────────────────────
        inv.setItem(9,  sectionLabel(Material.LIME_STAINED_GLASS_PANE, "─── Core Settings ───"));
        inv.setItem(10, makeToggle(Material.LEVER, "Plugin On/Off",
            "Master toggle for chunk destruction", gs.isEnabled(), "enabled"));
        inv.setItem(11, makeToggle(Material.SKELETON_SKULL, "Hardcore Mode",
            "Players die permanently on death", gs.isHardcore(), "hardcore"));
        inv.setItem(12, makeToggle(Material.CHEST, "Block Drops",
            "Decayed blocks drop items", gs.isBlockDrops(), "drops"));
        inv.setItem(13, makeToggle(Material.BRICKS, "Protect Player Blocks",
            "Player-placed blocks won't decay", gs.isProtectPlayerPlaced(), "protect"));

        // ── GROUP 2: Decay tuning (row 3) ─────────────────────────────────────
        inv.setItem(18, sectionLabel(Material.YELLOW_STAINED_GLASS_PANE, "─── Decay Tuning ───"));
        inv.setItem(19, makeAdjustable("Min Decay %", gs.getMinPercent() + "%",
            List.of("§7Lower bound of decay per chunk entry",
                    "§eLeft-click §7-1%   §eRight-click §7+1%"), Material.LIME_DYE, "minpct"));
        inv.setItem(20, makeAdjustable("Max Decay %", gs.getMaxPercent() + "%",
            List.of("§7Upper bound of decay per chunk entry",
                    "§eLeft-click §7-1%   §eRight-click §7+1%"), Material.RED_DYE, "maxpct"));
        inv.setItem(21, makeAdjustable("Decay Speed", gs.getDecayDurationTicks() + " ticks  (" +
            String.format("%.1f", gs.getDecayDurationTicks() / 20.0) + "s)",
            List.of("§7How long the full decay animation takes",
                    "§7Min 5 ticks (0.25s)  Max 200 ticks (10s)",
                    "§eLeft-click §7-5 ticks   §eRight-click §7+5 ticks"), Material.CLOCK, "speed"));

        // ── GROUP 3: Advancement Push toggles (row 5) ─────────────────────────
        inv.setItem(27, sectionLabel(Material.PURPLE_STAINED_GLASS_PANE, "─── Advancement Push ───"));
        inv.setItem(28, makeToggle(Material.EXPERIENCE_BOTTLE, "Advancement Push",
            "Equal % range, grows per advancement", gs.isAdvancementPushEnabled(), "advpush"));

        // ── GROUP 4: AP numbers (row 6) ───────────────────────────────────────
        inv.setItem(36, sectionLabel(Material.PURPLE_STAINED_GLASS_PANE, "─── Advancement Push Settings ───"));
        inv.setItem(37, makeAdjustable("AP Starting Max", gs.getAdvancementPushMax() + "%",
            List.of("§7Upper limit when the game begins",
                    "§eLeft-click §7-1%   §eRight-click §7+1%"), Material.ARROW, "apmax"));
        inv.setItem(38, makeAdjustable("AP Increment", "+" + gs.getAdvancementPushIncrement() + "% per adv.",
            List.of("§7% added to the range per advancement earned",
                    "§eLeft-click §7-1   §eRight-click §7+1"), Material.EXPERIENCE_BOTTLE, "apincrement"));
        inv.setItem(39, makeAdjustable("AP Current Max", gs.getAdvancementPushCurrentMax() + "%",
            List.of("§7Current upper limit (live value)",
                    "§eClick to reset to starting max"), Material.RECOVERY_COMPASS, "apreset"));

        // ── Danger zone (row 5, slots 45-53) ─────────────────────────────────
        fillRow(inv, 5, border(Material.RED_STAINED_GLASS_PANE));
        inv.setItem(45, sectionLabel(Material.RED_STAINED_GLASS_PANE, "─── Danger Zone ───"));
        inv.setItem(46, makeDanger(Material.BARRIER, "§e⚠ Reset All Settings",
            List.of("§7Resets all plugin settings to defaults.",
                    "§7Does not affect the world.",
                    "§eClick to reset"), "resetsettings"));
        inv.setItem(48, makeDanger(Material.TNT, "§c§l✗ Reset World",
            List.of("§7Teleports all players to a random safe",
                    "§7location far away.",
                    "§7Resets Advancement Push progress.",
                    "§4§lThis cannot be undone!",
                    "§eClick to confirm"), "resetworld"));

        player.openInventory(inv);
    }

    // ─── Item builders ────────────────────────────────────────────────────────

    private ItemStack makeToggle(Material mat, String name, String desc, boolean enabled, String tag) {
        ItemStack item = new ItemStack(enabled ? mat : Material.BARRIER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name)
            .color(enabled ? NamedTextColor.GREEN : NamedTextColor.RED)
            .decoration(TextDecoration.ITALIC, false).decoration(TextDecoration.BOLD, true));
        meta.lore(List.of(
            Component.text(desc).color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
            Component.empty(),
            Component.text(enabled ? "✔ Enabled  —  click to disable" : "✘ Disabled  —  click to enable")
                .color(enabled ? NamedTextColor.GREEN : NamedTextColor.RED).decoration(TextDecoration.ITALIC, false)
        ));
        tag(meta, tag);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack makeAdjustable(String name, String value, List<String> desc, Material mat, String tag) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name + ": ").color(NamedTextColor.YELLOW)
            .append(Component.text(value).color(NamedTextColor.WHITE))
            .decoration(TextDecoration.ITALIC, false).decoration(TextDecoration.BOLD, true));
        List<Component> lore = new ArrayList<>();
        for (String s : desc) lore.add(Component.text(s).decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        tag(meta, tag);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack makeDanger(Material mat, String name, List<String> desc, String tag) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name).decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        for (String s : desc) lore.add(Component.text(s).decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        tag(meta, tag);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack sectionHeader(String text) {
        ItemStack item = new ItemStack(Material.ORANGE_STAINED_GLASS_PANE);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(text).color(NamedTextColor.GOLD)
            .decoration(TextDecoration.ITALIC, false).decoration(TextDecoration.BOLD, true));
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack sectionLabel(Material mat, String text) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(text).color(NamedTextColor.WHITE)
            .decoration(TextDecoration.ITALIC, false).decoration(TextDecoration.BOLD, true));
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack border(Material mat) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(" ").decoration(TextDecoration.ITALIC, false));
        item.setItemMeta(meta);
        return item;
    }

    private void fillRow(Inventory inv, int row, ItemStack item) {
        for (int i = row * 9; i < row * 9 + 9; i++) inv.setItem(i, item);
    }

    private void tag(ItemMeta meta, String value) {
        meta.getPersistentDataContainer().set(
            new NamespacedKey(plugin, "cd_admin"), PersistentDataType.STRING, value);
    }

    // ─── Click handler ────────────────────────────────────────────────────────

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!event.getView().title().equals(TITLE)) return;
        event.setCancelled(true);
        if (!player.hasPermission("chunkdestruction.admin")) return;

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;
        String tag = clicked.getItemMeta().getPersistentDataContainer()
            .get(new NamespacedKey(plugin, "cd_admin"), PersistentDataType.STRING);
        if (tag == null) return;

        boolean isRight = event.isRightClick();
        GameState gs = plugin.getGameState();

        switch (tag) {
            case "enabled"    -> gs.setEnabled(!gs.isEnabled());
            case "hardcore"   -> { gs.setHardcore(!gs.isHardcore()); Bukkit.getOnlinePlayers().forEach(p -> p.getWorld().setHardcore(gs.isHardcore())); }
            case "drops"      -> gs.setBlockDrops(!gs.isBlockDrops());
            case "protect"    -> gs.setProtectPlayerPlaced(!gs.isProtectPlayerPlaced());
            case "speed"      -> gs.setDecayDurationTicks(Math.max(5, Math.min(200, gs.getDecayDurationTicks() + (isRight ? 5 : -5))));
            case "minpct"     -> gs.setMinPercent(Math.max(1, Math.min(gs.getMaxPercent() - 1, gs.getMinPercent() + (isRight ? 1 : -1))));
            case "maxpct"     -> gs.setMaxPercent(Math.max(gs.getMinPercent() + 1, Math.min(100, gs.getMaxPercent() + (isRight ? 1 : -1))));
            case "advpush"    -> { gs.setAdvancementPushEnabled(!gs.isAdvancementPushEnabled()); plugin.getBossbarManager().update(); }
            case "apmax"      -> gs.setAdvancementPushMax(Math.max(0, Math.min(100, gs.getAdvancementPushMax() + (isRight ? 1 : -1))));
            case "apincrement"-> gs.setAdvancementPushIncrement(Math.max(1, gs.getAdvancementPushIncrement() + (isRight ? 1 : -1)));
            case "apreset"    -> { gs.resetAdvancementPush(); plugin.getBossbarManager().update(); player.sendMessage(Component.text("§aAdvancement Push reset to starting max.")); }
            case "resetsettings" -> {
                gs.resetToDefaults();
                plugin.getBossbarManager().update();
                player.sendMessage(Component.text("§aAll settings reset to defaults."));
            }
            case "resetworld" -> doWorldReset(player);
        }
        open(player);
    }

    // ─── World reset ──────────────────────────────────────────────────────────

    private void doWorldReset(Player initiator) {
        World world = initiator.getWorld();
        GameState gs = plugin.getGameState();

        initiator.sendMessage(Component.text("§c§lResetting — finding safe location and teleporting all players..."));

        // Find a safe random location far away on the surface
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            int attempts = 0;
            Location safeLoc = null;

            while (attempts < 20 && safeLoc == null) {
                // Random direction, 800k-1.2m blocks away
                double angle = random.nextDouble() * 2 * Math.PI;
                double dist = 800000 + random.nextDouble() * 400000;
                int tx = (int)(Math.cos(angle) * dist);
                int tz = (int)(Math.sin(angle) * dist);

                Bukkit.getScheduler().runTask(plugin, () -> {
                    // Force chunk load to get height
                });

                // Get surface Y — run sync to query world
                final int finalTx = tx, finalTz = tz;
                final Location[] result = {null};
                try {
                    Bukkit.getScheduler().callSyncMethod(plugin, () -> {
                        int surfaceY = world.getHighestBlockYAt(finalTx, finalTz);
                        Location candidate = new Location(world, finalTx + 0.5, surfaceY + 1.5, finalTz + 0.5);
                        // Check 3 blocks of space above surface
                        if (world.getBlockAt(finalTx, surfaceY + 1, finalTz).getType().isAir()
                            && world.getBlockAt(finalTx, surfaceY + 2, finalTz).getType().isAir()
                            && !world.getBlockAt(finalTx, surfaceY, finalTz).getType().isAir()) {
                            result[0] = candidate;
                        }
                        return null;
                    }).get();
                } catch (Exception e) { /* try again */ }

                if (result[0] != null) safeLoc = result[0];
                attempts++;
            }

            final Location teleportTo = safeLoc != null ? safeLoc :
                new Location(world, 1000000.5, world.getHighestBlockYAt(1000000, 1000000) + 1.5, 1000000.5);

            final Location finalSafeLoc = teleportTo;
            Bukkit.getScheduler().runTask(plugin, () -> {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    p.teleport(finalSafeLoc);
                    p.sendMessage(Component.text("§cThe world has been reset. You've been moved to a safe location."));
                }
                if (gs.isAdvancementPushEnabled()) {
                    gs.resetAdvancementPush();
                    plugin.getBossbarManager().update();
                }
            });
        });
    }
}
