package dev.chunkdestruction.managers;

import dev.chunkdestruction.ChunkDestructionPlugin;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.entity.Player;

public class BossbarManager {

    private final ChunkDestructionPlugin plugin;
    private final BossBar bossBar;

    public BossbarManager(ChunkDestructionPlugin plugin) {
        this.plugin = plugin;
        bossBar = BossBar.bossBar(
            Component.text("⚡ Advancement Push").color(NamedTextColor.YELLOW),
            0.1f, BossBar.Color.GREEN, BossBar.Overlay.NOTCHED_20
        );
    }

    public void update() {
        GameState gs = plugin.getGameState();
        if (!gs.isAdvancementPushEnabled()) { hideFromAll(); return; }

        int currentMax = gs.getAdvancementPushCurrentMax();
        int effectiveMin = gs.getEffectiveMin();

        // Progress bar: simply how far currentMax is toward 100
        float progress = Math.max(0.01f, Math.min(1f, currentMax / 100f));

        BossBar.Color color = currentMax <= 33 ? BossBar.Color.GREEN
            : currentMax <= 66 ? BossBar.Color.YELLOW
            : BossBar.Color.RED;
        NamedTextColor textColor = currentMax <= 33 ? NamedTextColor.GREEN
            : currentMax <= 66 ? NamedTextColor.YELLOW
            : NamedTextColor.RED;

        Component title = Component.text("⚡ Decay Range: ")
            .color(NamedTextColor.WHITE).decoration(TextDecoration.BOLD, true).decoration(TextDecoration.ITALIC, false)
            .append(Component.text(effectiveMin + "% — " + currentMax + "%")
                .color(textColor).decoration(TextDecoration.BOLD, true))
            .append(Component.text("  (+" + gs.getAdvancementPushIncrement() + "% max")
                .color(NamedTextColor.GRAY).decoration(TextDecoration.BOLD, false))
            .append(Component.text(gs.isAdvancementPushMinGrows() ? ", +0.5% min per adv.)" : " per adv.)")
                .color(NamedTextColor.GRAY).decoration(TextDecoration.BOLD, false));

        bossBar.name(title);
        bossBar.progress(progress);
        bossBar.color(color);

        for (Player p : plugin.getServer().getOnlinePlayers()) {
            if (gs.isBossbarEnabled(p.getUniqueId())) p.showBossBar(bossBar);
            else p.hideBossBar(bossBar);
        }
    }

    public void showTo(Player player) {
        if (plugin.getGameState().isAdvancementPushEnabled()
                && plugin.getGameState().isBossbarEnabled(player.getUniqueId()))
            player.showBossBar(bossBar);
    }

    public void hideFrom(Player player) { player.hideBossBar(bossBar); }

    public void hideFromAll() {
        for (Player p : plugin.getServer().getOnlinePlayers()) p.hideBossBar(bossBar);
    }
}
