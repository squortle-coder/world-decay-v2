package dev.chunkdestruction.managers;

import dev.chunkdestruction.ChunkDestructionPlugin;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class GameState {

    private final ChunkDestructionPlugin plugin;

    private boolean enabled;
    private int minPercent;
    private int maxPercent;
    private int decayDurationTicks;
    private boolean blockDrops;
    private boolean protectPlayerPlaced;
    private boolean breakSound;
    private boolean hardcore;

    private boolean advancementPushEnabled;
    private int advancementPushStartMin;      // starting min (default 0)
    private int advancementPushStartMax;      // starting max (default 10)
    private int advancementPushIncrement;     // how much max grows per adv
    private boolean advancementPushMinGrows;  // whether min also grows
    private int advancementPushCurrentMax;    // current live max
    private float advancementPushCurrentMin;  // current live min (float for 0.5 steps)
    private boolean advancementPushBossbar;

    private final Set<UUID> actionbarDisabled = new HashSet<>();
    private final Set<UUID> bossbarDisabled   = new HashSet<>();
    private final Set<UUID> soundDisabled     = new HashSet<>();
    private final Set<Long> playerPlacedBlocks = new HashSet<>();

    private static final int   DEFAULT_MIN         = 2;
    private static final int   DEFAULT_MAX         = 95;
    private static final int   DEFAULT_DECAY_TICKS = 40;
    private static final int   DEFAULT_AP_START_MIN = 0;
    private static final int   DEFAULT_AP_START_MAX = 10;
    private static final int   DEFAULT_AP_INCREMENT = 1;
    private static final boolean DEFAULT_AP_MIN_GROWS = true;

    public GameState(ChunkDestructionPlugin plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        FileConfiguration cfg = plugin.getConfig();
        enabled               = cfg.getBoolean("enabled", true);
        minPercent            = cfg.getInt("min-percent", DEFAULT_MIN);
        maxPercent            = cfg.getInt("max-percent", DEFAULT_MAX);
        decayDurationTicks    = cfg.getInt("decay-duration-ticks", DEFAULT_DECAY_TICKS);
        blockDrops            = cfg.getBoolean("block-drops", false);
        protectPlayerPlaced   = cfg.getBoolean("protect-player-placed", false);
        breakSound            = cfg.getBoolean("break-sound", true);
        hardcore              = cfg.getBoolean("hardcore", false);
        advancementPushEnabled  = cfg.getBoolean("advancement-push-enabled", false);
        advancementPushStartMin = cfg.getInt("advancement-push-start-min", DEFAULT_AP_START_MIN);
        advancementPushStartMax = cfg.getInt("advancement-push-start-max", DEFAULT_AP_START_MAX);
        advancementPushIncrement = cfg.getInt("advancement-push-increment", DEFAULT_AP_INCREMENT);
        advancementPushMinGrows = cfg.getBoolean("advancement-push-min-grows", DEFAULT_AP_MIN_GROWS);
        advancementPushCurrentMax = cfg.getInt("advancement-push-current-max", advancementPushStartMax);
        advancementPushCurrentMin = (float) cfg.getDouble("advancement-push-current-min", advancementPushStartMin);
        advancementPushBossbar  = cfg.getBoolean("advancement-push-bossbar", true);
    }

    public void save() {
        FileConfiguration cfg = plugin.getConfig();
        cfg.set("enabled", enabled);
        cfg.set("min-percent", minPercent);
        cfg.set("max-percent", maxPercent);
        cfg.set("decay-duration-ticks", decayDurationTicks);
        cfg.set("block-drops", blockDrops);
        cfg.set("protect-player-placed", protectPlayerPlaced);
        cfg.set("break-sound", breakSound);
        cfg.set("hardcore", hardcore);
        cfg.set("advancement-push-enabled", advancementPushEnabled);
        cfg.set("advancement-push-start-min", advancementPushStartMin);
        cfg.set("advancement-push-start-max", advancementPushStartMax);
        cfg.set("advancement-push-increment", advancementPushIncrement);
        cfg.set("advancement-push-min-grows", advancementPushMinGrows);
        cfg.set("advancement-push-current-max", advancementPushCurrentMax);
        cfg.set("advancement-push-current-min", (double) advancementPushCurrentMin);
        cfg.set("advancement-push-bossbar", advancementPushBossbar);
        plugin.saveConfig();
    }

    public void resetToDefaults() {
        enabled = true;
        minPercent = DEFAULT_MIN;
        maxPercent = DEFAULT_MAX;
        decayDurationTicks = DEFAULT_DECAY_TICKS;
        blockDrops = false;
        protectPlayerPlaced = false;
        breakSound = true;
        hardcore = false;
        advancementPushEnabled = false;
        advancementPushStartMin = DEFAULT_AP_START_MIN;
        advancementPushStartMax = DEFAULT_AP_START_MAX;
        advancementPushIncrement = DEFAULT_AP_INCREMENT;
        advancementPushMinGrows = DEFAULT_AP_MIN_GROWS;
        advancementPushCurrentMax = DEFAULT_AP_START_MAX;
        advancementPushCurrentMin = DEFAULT_AP_START_MIN;
        advancementPushBossbar = true;
        save();
    }

    /** Called when a valid advancement is earned — increments both max and optionally min */
    public void incrementAdvancementPush() {
        advancementPushCurrentMax = Math.min(advancementPushCurrentMax + advancementPushIncrement, 100);
        if (advancementPushMinGrows) {
            advancementPushCurrentMin = Math.min(advancementPushCurrentMin + 0.5f, advancementPushCurrentMax - 1);
        }
        save();
    }

    public void resetAdvancementPush() {
        advancementPushCurrentMax = advancementPushStartMax;
        advancementPushCurrentMin = advancementPushStartMin;
        save();
    }

    /** Returns the current effective min as an integer (floor) */
    public int getEffectiveMin() {
        return (int) advancementPushCurrentMin;
    }

    public static long encodeBlock(int x, int y, int z) {
        return ((long)(x + 30000000) << 40) | ((long)(z + 30000000) << 16) | (y + 2048);
    }

    // ── Getters / setters ──────────────────────────────────────────────────────

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean v) { enabled = v; save(); }

    public int getMinPercent() { return minPercent; }
    public void setMinPercent(int v) { minPercent = v; save(); }

    public int getMaxPercent() { return maxPercent; }
    public void setMaxPercent(int v) { maxPercent = v; save(); }

    public int getDecayDurationTicks() { return decayDurationTicks; }
    public void setDecayDurationTicks(int v) { decayDurationTicks = v; save(); }

    public boolean isBlockDrops() { return blockDrops; }
    public void setBlockDrops(boolean v) { blockDrops = v; save(); }

    public boolean isProtectPlayerPlaced() { return protectPlayerPlaced; }
    public void setProtectPlayerPlaced(boolean v) { protectPlayerPlaced = v; save(); }

    public boolean isBreakSound() { return breakSound; }
    public void setBreakSound(boolean v) { breakSound = v; save(); }

    public boolean isHardcore() { return hardcore; }
    public void setHardcore(boolean v) { hardcore = v; save(); }

    public boolean isAdvancementPushEnabled() { return advancementPushEnabled; }
    public void setAdvancementPushEnabled(boolean v) { advancementPushEnabled = v; save(); }

    public int getAdvancementPushStartMin() { return advancementPushStartMin; }
    public void setAdvancementPushStartMin(int v) { advancementPushStartMin = v; save(); }

    public int getAdvancementPushStartMax() { return advancementPushStartMax; }
    public void setAdvancementPushStartMax(int v) { advancementPushStartMax = v; save(); }

    public int getAdvancementPushIncrement() { return advancementPushIncrement; }
    public void setAdvancementPushIncrement(int v) { advancementPushIncrement = v; save(); }

    public boolean isAdvancementPushMinGrows() { return advancementPushMinGrows; }
    public void setAdvancementPushMinGrows(boolean v) { advancementPushMinGrows = v; save(); }

    public int getAdvancementPushCurrentMax() { return advancementPushCurrentMax; }
    public void setAdvancementPushCurrentMax(int v) { advancementPushCurrentMax = Math.min(v, 100); save(); }

    public float getAdvancementPushCurrentMin() { return advancementPushCurrentMin; }

    public boolean isAdvancementPushBossbar() { return advancementPushBossbar; }
    public void setAdvancementPushBossbar(boolean v) { advancementPushBossbar = v; save(); }

    public boolean isActionbarEnabled(UUID uuid) { return !actionbarDisabled.contains(uuid); }
    public void toggleActionbar(UUID uuid) { if (!actionbarDisabled.remove(uuid)) actionbarDisabled.add(uuid); }

    public boolean isBossbarEnabled(UUID uuid) { return !bossbarDisabled.contains(uuid); }
    public void toggleBossbar(UUID uuid) { if (!bossbarDisabled.remove(uuid)) bossbarDisabled.add(uuid); }

    public boolean isSoundEnabled(UUID uuid) { return !soundDisabled.contains(uuid); }
    public void toggleSound(UUID uuid) { if (!soundDisabled.remove(uuid)) soundDisabled.add(uuid); }

    public void markPlayerPlaced(int x, int y, int z) { playerPlacedBlocks.add(encodeBlock(x, y, z)); }
    public void unmarkPlayerPlaced(int x, int y, int z) { playerPlacedBlocks.remove(encodeBlock(x, y, z)); }
    public boolean isPlayerPlaced(int x, int y, int z) { return playerPlacedBlocks.contains(encodeBlock(x, y, z)); }
}
