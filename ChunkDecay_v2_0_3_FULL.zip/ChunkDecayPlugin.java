package me.adam.chunkdecay;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.boss.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

public class ChunkDecayPlugin extends JavaPlugin implements Listener {

    private final Map<String, Long> cooldowns = new HashMap<>();
    private final Random random = new Random();

    private final Set<UUID> actionbarOff = new HashSet<>();
    private final Set<UUID> bossbarOff = new HashSet<>();
    private final Set<UUID> soundOff = new HashSet<>();
    private final Set<Block> playerPlaced = new HashSet<>();

    private boolean enabled = true;
    private boolean advancementMode = false;
    private boolean blockDrops = false;
    private boolean ignorePlayerBlocks = false;

    private int advMax = 10;

    enum AnimationMode { BREAK, SHRINK }
    private AnimationMode animationMode = AnimationMode.BREAK;

    private BossBar bossBar;

    private final long COOLDOWN = 10000;

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        bossBar = Bukkit.createBossBar("Decay Range: 0–10%", BarColor.RED, BarStyle.SEGMENTED_10);
    }

    @EventHandler
    public void onAdv(PlayerAdvancementDoneEvent e) {
        if (!advancementMode) return;

        advMax = Math.min(99, advMax + 1);
        bossBar.setTitle("Decay Range: 0–" + advMax + "%");
        bossBar.setProgress(advMax / 100.0);

        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!bossbarOff.contains(p.getUniqueId())) bossBar.addPlayer(p);
        }
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        playerPlaced.add(e.getBlock());
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        if (!enabled || e.getTo() == null) return;
        if (e.getFrom().getChunk().equals(e.getTo().getChunk())) return;

        Chunk chunk = e.getTo().getChunk();
        String key = chunk.getX() + "," + chunk.getZ();

        long now = System.currentTimeMillis();
        if (cooldowns.containsKey(key) && now - cooldowns.get(key) < COOLDOWN) return;

        cooldowns.put(key, now);

        int percent = getPercent();
        showActionbar(e.getPlayer(), percent);
        decay(chunk, percent);
    }

    private int getPercent() {
        if (advancementMode) return random.nextInt(advMax + 1);

        int roll = random.nextInt(1000);
        if (roll < 600) return 1 + random.nextInt(14);
        if (roll < 900) return 15 + random.nextInt(25);
        if (roll < 990) return 40 + random.nextInt(30);
        return 70 + random.nextInt(30);
    }

    private boolean isProtected(Material m) {
        return m == Material.END_PORTAL
                || m == Material.END_PORTAL_FRAME
                || m.name().contains("TRIAL")
                || m.name().contains("VAULT")
                || m == Material.SPAWNER;
    }

    private void decay(Chunk chunk, int percent) {
        List<Block> blocks = new ArrayList<>();
        World w = chunk.getWorld();

        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                for (int y = w.getMaxHeight(); y > w.getMinHeight(); y--) {
                    Block b = chunk.getBlock(x, y, z);
                    if (b.getType().isAir()) continue;
                    if (isProtected(b.getType())) continue;
                    if (ignorePlayerBlocks && playerPlaced.contains(b)) continue;
                    blocks.add(b);
                }
            }
        }

        blocks.sort((a, b) -> Integer.compare(b.getY(), a.getY()));
        int remove = (int)(blocks.size() * percent / 100.0);

        for (int i = 0; i < remove; i++) {
            Block b = blocks.get(i);

            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (animationMode == AnimationMode.BREAK) {
                    if (blockDrops) b.breakNaturally();
                    else b.setType(Material.AIR);
                } else {
                    Location loc = b.getLocation().add(0.5,0.5,0.5);
                    BlockDisplay d = (BlockDisplay) b.getWorld().spawnEntity(loc, EntityType.BLOCK_DISPLAY);
                    d.setBlock(b.getBlockData());
                    b.setType(Material.AIR);
                    Bukkit.getScheduler().runTaskLater(this, d::remove, 20L);
                }

                if (!soundOff.contains(null))
                    b.getWorld().playSound(b.getLocation(), Sound.BLOCK_STONE_BREAK, 1f, 1f);

            }, i * 2L);
        }
    }

    private void showActionbar(Player p, int percent) {
        if (actionbarOff.contains(p.getUniqueId())) return;

        ChatColor c = percent <= 20 ? ChatColor.GREEN :
                      percent <= 35 ? ChatColor.YELLOW :
                      ChatColor.RED;

        p.sendActionBar(c + percent + "% decay");
    }

    @EventHandler
    public void onCmd(PlayerCommandPreprocessEvent e) {
        if (e.getMessage().equalsIgnoreCase("/cd settings")) {
            openSettings(e.getPlayer());
            e.setCancelled(true);
        }
        if (e.getMessage().equalsIgnoreCase("/cd admin")) {
            openAdmin(e.getPlayer());
            e.setCancelled(true);
        }
    }

    private void openSettings(Player p) {
        Inventory gui = Bukkit.createInventory(null, 9, "Settings");
        gui.setItem(1, item(Material.PAPER, "Actionbar"));
        gui.setItem(4, item(Material.DIAMOND, "Bossbar"));
        gui.setItem(7, item(Material.NOTE_BLOCK, "Sounds"));
        p.openInventory(gui);
    }

    private void openAdmin(Player p) {
        Inventory gui = Bukkit.createInventory(null, 9, "Admin");
        gui.setItem(0, item(Material.LEVER, "Enable Plugin"));
        gui.setItem(1, item(Material.NETHER_STAR, "Advancement Mode"));
        gui.setItem(2, item(Material.DIRT, "Block Drops"));
        gui.setItem(3, item(Material.GRASS_BLOCK, "Ignore Player Blocks"));
        gui.setItem(4, item(Material.AMETHYST_SHARD, "Animation Mode"));
        gui.setItem(8, item(Material.BARRIER, "Reset World"));
        p.openInventory(gui);
    }

    private ItemStack item(Material m, String name) {
        ItemStack i = new ItemStack(m);
        ItemMeta meta = i.getItemMeta();
        meta.setDisplayName(ChatColor.YELLOW + name);
        i.setItemMeta(meta);
        return i;
    }

    @EventHandler
    public void click(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        e.setCancelled(true);

        String t = e.getView().getTitle();

        if (t.equals("Settings")) {
            if (e.getSlot() == 1) toggle(actionbarOff, p);
            if (e.getSlot() == 4) toggle(bossbarOff, p);
            if (e.getSlot() == 7) toggle(soundOff, p);
        }

        if (t.equals("Admin")) {
            switch (e.getSlot()) {
                case 0 -> enabled = !enabled;
                case 1 -> advancementMode = !advancementMode;
                case 2 -> blockDrops = !blockDrops;
                case 3 -> ignorePlayerBlocks = !ignorePlayerBlocks;
                case 4 -> animationMode = (animationMode == AnimationMode.BREAK ? AnimationMode.SHRINK : AnimationMode.BREAK);
                case 8 -> resetWorld();
            }
        }
    }

    private void toggle(Set<UUID> set, Player p) {
        if (set.contains(p.getUniqueId())) {
            set.remove(p.getUniqueId());
            p.sendMessage("Enabled");
        } else {
            set.add(p.getUniqueId());
            p.sendMessage("Disabled");
        }
    }

    private void resetWorld() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.teleport(new Location(p.getWorld(), 1000000, 100, 1000000));
        }
        cooldowns.clear();
    }
}
